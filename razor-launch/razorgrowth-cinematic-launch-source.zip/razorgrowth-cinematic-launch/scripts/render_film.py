"""
RazorGrowth AI — Master Video Rendering & Encoding Pipeline
Streams 1920x1080 30fps BGRA surfaces directly from PyCairo to FFmpeg (H.264 + AAC 48kHz Stereo).
"""
import argparse
import os
import subprocess
import sys
import time
import cairo

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.styles.tokens import WIDTH, HEIGHT, FPS, FONT_DISPLAY, FONT_SANS, FONT_MONO
from src.timeline import render_frame_at_time, render_teaser_frame_at_time
from audio.synthesize_audio import generate_all_audio


def warmup_fonts(ctx: cairo.Context):
    for fam in (FONT_DISPLAY, FONT_SANS, FONT_MONO):
        for w in (cairo.FONT_WEIGHT_NORMAL, cairo.FONT_WEIGHT_BOLD):
            ctx.select_font_face(fam, cairo.FONT_SLANT_NORMAL, w)
            ctx.set_font_size(24)
            ctx.move_to(-100, -100)
            ctx.show_text("RazorGrowth AI Warmup")


def start_ffmpeg_writer(output_mp4: str, audio_wav: str, duration_sec: float):
    os.makedirs(os.path.dirname(output_mp4), exist_ok=True)
    cmd = [
        "ffmpeg",
        "-y",
        "-f", "rawvideo",
        "-vcodec", "rawvideo",
        "-pix_fmt", "bgra",
        "-s", f"{WIDTH}x{HEIGHT}",
        "-r", str(FPS),
        "-i", "-",
        "-i", audio_wav,
        "-c:v", "libx264",
        "-preset", "faster",
        "-crf", "18",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "192k",
        "-ar", "48000",
        "-ac", "2",
        "-t", f"{duration_sec:.2f}",
        "-movflags", "+faststart",
        output_mp4,
    ]
    return subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)


def render_preview_mp4(intermediate_dir: str = None):
    """
    Renders previews/razorgrowth-ai-preview.mp4 (24.0s @ 30fps = 720 frames) covering:
    - 00..06s: Scene 1 (Opening Business World & 2.5D->3D transformation)
    - 06..12s: Scene 3 (Meet the AI Team 3D companions & 15-agent ecosystem)
    - 12..18s: Scene 6 (Human Approval centerpiece & cursor click)
    - 18..24s: Scene 8 (Brand Finale)
    Also exports representative PNG frames for visual QA inspection.
    """
    out_mp4 = os.path.join(PROJECT_ROOT, "previews", "razorgrowth-ai-preview.mp4")
    wav_path = os.path.join(PROJECT_ROOT, "audio", "razorgrowth_preview_24s.wav")
    if not os.path.exists(wav_path):
        generate_all_audio(PROJECT_ROOT)

    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, WIDTH, HEIGHT)
    ctx = cairo.Context(surf)
    scratch_surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, WIDTH, HEIGHT)
    scratch_ctx = cairo.Context(scratch_surf)
    warmup_fonts(ctx)

    total_frames = 24 * FPS
    proc = start_ffmpeg_writer(out_mp4, wav_path, 24.0)
    t0 = time.time()

    for f in range(total_frames):
        pt = f / float(FPS)
        if pt < 6.0:
            film_t = pt
        elif pt < 12.0:
            film_t = 13.0 + (pt - 6.0)
        elif pt < 18.0:
            film_t = 39.5 + (pt - 12.0)
        else:
            film_t = 55.5 + (pt - 18.0)

        render_frame_at_time(ctx, film_t, scratch_surf, scratch_ctx)
        proc.stdin.write(surf.get_data())

    proc.stdin.close()
    stderr_out = proc.stderr.read().decode("utf-8", errors="replace")
    ret = proc.wait()
    if ret != 0:
        raise RuntimeError(f"FFmpeg preview encode failed: {stderr_out}")

    # Export key QA frames across all 8 scenes if intermediate_dir is provided
    if intermediate_dir:
        os.makedirs(intermediate_dir, exist_ok=True)
        qa_timestamps = [
            ("scene1_business_world.png", 3.4),
            ("scene2_product_reveal.png", 9.8),
            ("scene3_ai_team_3d.png", 17.5),
            ("scene4_growth_radar.png", 26.5),
            ("scene5_agent_debates.png", 34.8),
            ("scene6_human_approval.png", 43.2),
            ("scene7_growth_os_campus.png", 51.5),
            ("scene8_brand_finale.png", 59.0),
        ]
        for fname, ts in qa_timestamps:
            render_frame_at_time(ctx, ts, scratch_surf, scratch_ctx)
            surf.write_to_png(os.path.join(intermediate_dir, fname))

    print(f"[Preview Render] Completed {out_mp4} in {time.time() - t0:.2f}s")
    return out_mp4


def render_full_launch_mp4():
    """Renders renders/razorgrowth-ai-launch.mp4 (62.0s @ 30fps = 1860 frames)."""
    out_mp4 = os.path.join(PROJECT_ROOT, "renders", "razorgrowth-ai-launch.mp4")
    wav_path = os.path.join(PROJECT_ROOT, "audio", "razorgrowth_launch_62s.wav")
    if not os.path.exists(wav_path):
        generate_all_audio(PROJECT_ROOT)

    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, WIDTH, HEIGHT)
    ctx = cairo.Context(surf)
    scratch_surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, WIDTH, HEIGHT)
    scratch_ctx = cairo.Context(scratch_surf)
    warmup_fonts(ctx)

    total_frames = int(62.0 * FPS)
    proc = start_ffmpeg_writer(out_mp4, wav_path, 62.0)
    t0 = time.time()

    for f in range(total_frames):
        t = f / float(FPS)
        render_frame_at_time(ctx, t, scratch_surf, scratch_ctx)
        proc.stdin.write(surf.get_data())

    proc.stdin.close()
    stderr_out = proc.stderr.read().decode("utf-8", errors="replace")
    ret = proc.wait()
    if ret != 0:
        raise RuntimeError(f"FFmpeg full launch encode failed: {stderr_out}")

    print(f"[Full Launch Render] Completed {out_mp4} ({total_frames} frames) in {time.time() - t0:.2f}s")
    return out_mp4


def render_teaser_mp4():
    """Renders renders/razorgrowth-ai-teaser-15s.mp4 (15.0s @ 30fps = 450 frames)."""
    out_mp4 = os.path.join(PROJECT_ROOT, "renders", "razorgrowth-ai-teaser-15s.mp4")
    wav_path = os.path.join(PROJECT_ROOT, "audio", "razorgrowth_teaser_15s.wav")
    if not os.path.exists(wav_path):
        generate_all_audio(PROJECT_ROOT)

    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, WIDTH, HEIGHT)
    ctx = cairo.Context(surf)
    scratch_surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, WIDTH, HEIGHT)
    scratch_ctx = cairo.Context(scratch_surf)
    warmup_fonts(ctx)

    total_frames = int(15.0 * FPS)
    proc = start_ffmpeg_writer(out_mp4, wav_path, 15.0)
    t0 = time.time()

    for f in range(total_frames):
        t = f / float(FPS)
        render_teaser_frame_at_time(ctx, t, scratch_surf, scratch_ctx)
        proc.stdin.write(surf.get_data())

    proc.stdin.close()
    stderr_out = proc.stderr.read().decode("utf-8", errors="replace")
    ret = proc.wait()
    if ret != 0:
        raise RuntimeError(f"FFmpeg teaser encode failed: {stderr_out}")

    print(f"[Teaser Render] Completed {out_mp4} ({total_frames} frames) in {time.time() - t0:.2f}s")
    return out_mp4


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["preview", "full", "teaser", "all"], default="all")
    parser.add_argument(
        "--qa-dir",
        default="/working_dir/c_e31c4b5308c9e057/artifacts/file_generation/ttl=63d/intermediate/qa_frames",
    )
    args = parser.parse_args()

    generate_all_audio(PROJECT_ROOT)
    if args.mode in ("preview", "all"):
        render_preview_mp4(args.qa_dir)
    if args.mode in ("full", "all"):
        render_full_launch_mp4()
    if args.mode in ("teaser", "all"):
        render_teaser_mp4()
