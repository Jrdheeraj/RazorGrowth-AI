"""
RazorGrowth AI — Original Procedural Score & Synchronized Sound Design Generator
Synthesizes stereo 48 kHz WAV tracks for:
1. Full 62.0s Launch Film (audio/razorgrowth_launch_62s.wav)
2. 24.0s Representative Preview Reel (audio/razorgrowth_preview_24s.wav)
3. 15.0s Teaser Film (audio/razorgrowth_teaser_15s.wav)

License & Attribution:
100% original procedural synthesis created specifically for RazorGrowth AI using NumPy/SciPy.
No external or copyrighted audio samples are used.
"""
import os
import wave
import numpy as np

SR = 48000


def add_event(buf_l, buf_r, start_sec, wave_l, wave_r=None):
    if wave_r is None:
        wave_r = wave_l
    idx0 = int(start_sec * SR)
    if idx0 >= len(buf_l) or idx0 < 0:
        return
    n = min(len(wave_l), len(buf_l) - idx0)
    buf_l[idx0 : idx0 + n] += wave_l[:n]
    buf_r[idx0 : idx0 + n] += wave_r[:n]


def synth_warm_pad_chord(freqs, duration, amp=0.10, pan_spread=0.25):
    t = np.linspace(0, duration, int(duration * SR), endpoint=False)
    env = np.ones_like(t)
    atk = min(int(0.85 * SR), len(t) // 3)
    rel = min(int(1.25 * SR), len(t) // 3)
    env[:atk] = np.linspace(0, 1, atk) ** 1.5
    env[-rel:] = np.linspace(1, 0, rel) ** 1.8

    out_l = np.zeros_like(t)
    out_r = np.zeros_like(t)
    for idx, f in enumerate(freqs):
        # Warm analog-style detuned sine + soft triangle overtone
        detune = 1.0 + (idx - 1.5) * 0.0012
        sig = (
            0.72 * np.sin(2 * np.pi * f * detune * t)
            + 0.20 * np.sin(2 * np.pi * (f * 2.0) * t + 0.4) * np.exp(-t * 0.35)
            + 0.08 * np.sin(2 * np.pi * (f * 0.5) * t)
        )
        pan = 0.5 + ((idx % 2) * 2 - 1) * pan_spread
        out_l += sig * (1.0 - pan)
        out_r += sig * pan

    scale = amp / max(1, len(freqs))
    return out_l * env * scale, out_r * env * scale


def synth_tactile_marimba_note(freq, duration=0.38, amp=0.09, pan=0.5):
    t = np.linspace(0, duration, int(duration * SR), endpoint=False)
    env = np.exp(-t * 11.5) * (1.0 - np.exp(-t * 180.0))
    sig = (
        np.sin(2 * np.pi * freq * t)
        + 0.28 * np.sin(2 * np.pi * freq * 3.0 * t) * np.exp(-t * 28.0)
        + 0.12 * np.sin(2 * np.pi * freq * 4.0 * t) * np.exp(-t * 45.0)
    ) * env * amp
    return sig * (1.0 - pan), sig * pan


def synth_card_placement(amp=0.08, pan=0.5):
    dur = 0.14
    t = np.linspace(0, dur, int(dur * SR), endpoint=False)
    # Soft warm low-mid thud + gentle paper brush
    f_sweep = np.linspace(170.0, 68.0, len(t))
    phase = 2 * np.pi * np.cumsum(f_sweep) / SR
    body = np.sin(phase) * np.exp(-t * 32.0)
    click = np.sin(2 * np.pi * 920.0 * t) * np.exp(-t * 95.0) * 0.25
    sig = (body + click) * amp
    return sig * (1.0 - pan), sig * pan


def synth_ui_click(amp=0.07, pan=0.5):
    dur = 0.045
    t = np.linspace(0, dur, int(dur * SR), endpoint=False)
    sig = (
        np.sin(2 * np.pi * 1480.0 * t) * np.exp(-t * 140.0)
        + 0.5 * np.sin(2 * np.pi * 740.0 * t) * np.exp(-t * 90.0)
    ) * amp
    return sig * (1.0 - pan), sig * pan


def synth_low_reveal_accent(freq=55.0, dur=1.6, amp=0.14):
    t = np.linspace(0, dur, int(dur * SR), endpoint=False)
    env = (1.0 - np.exp(-t * 18.0)) * np.exp(-t * 2.4)
    sig = (
        np.sin(2 * np.pi * freq * t)
        + 0.35 * np.sin(2 * np.pi * (freq * 1.5) * t)
        + 0.18 * np.sin(2 * np.pi * (freq * 2.0) * t) * np.exp(-t * 4.0)
    ) * env * amp
    return sig, sig


def synth_approval_chime(amp=0.14):
    """Delicate warm terracotta/sage confirmation chord for Human Approval."""
    dur = 1.85
    t = np.linspace(0, dur, int(dur * SR), endpoint=False)
    # D major 9th warm bell resolution: D5 (587.33), F#5 (739.99), A5 (880.0), E6 (1318.5)
    notes = [(587.33, 0.0, 0.38), (739.99, 0.06, 0.62), (880.00, 0.12, 0.42), (1174.66, 0.18, 0.58)]
    out_l = np.zeros_like(t)
    out_r = np.zeros_like(t)
    for freq, delay, pan in notes:
        mask = t >= delay
        lt = np.maximum(0.0, t - delay)
        env = mask * (1.0 - np.exp(-lt * 120.0)) * np.exp(-lt * 3.2)
        tone = (
            np.sin(2 * np.pi * freq * lt)
            + 0.22 * np.sin(2 * np.pi * freq * 2.0 * lt) * np.exp(-lt * 6.5)
        ) * env * amp
        out_l += tone * (1.0 - pan)
        out_r += tone * pan
    return out_l, out_r


def generate_full_62s_score(filepath: str):
    dur = 62.0
    n_samples = int(dur * SR)
    buf_l = np.zeros(n_samples, dtype=np.float64)
    buf_r = np.zeros(n_samples, dtype=np.float64)

    # 1. Warm Cinematic Chord Progression across the 8 scenes (D Major / G Maj7 / Bm7 / Asus4 / D Maj9)
    chords = [
        # Scene 1 (0-6s): Curiosity & Warm Morning Horizon
        (0.0, 6.2, [146.83, 220.00, 293.66, 369.99], 0.12),
        # Scene 2 (6-13s): Product Reveal Lift (Gmaj7 -> Dmaj9)
        (5.8, 3.8, [196.00, 246.94, 293.66, 369.99], 0.15),
        (9.4, 3.8, [146.83, 220.00, 277.18, 329.63, 440.00], 0.16),
        # Scene 3 (13-22s): Meet the AI Team (Coordinated pulse)
        (13.0, 4.6, [246.94, 293.66, 369.99, 440.00], 0.15),
        (17.4, 4.8, [196.00, 293.66, 369.99, 493.88], 0.16),
        # Scene 4 (22-30s): Growth Radar (Analytical clarity)
        (22.0, 4.2, [164.81, 246.94, 329.63, 392.00], 0.15),
        (26.0, 4.2, [146.83, 220.00, 293.66, 440.00], 0.15),
        # Scene 5 (30-38s): Debate & Synthesis (Structured reasoning)
        (30.0, 4.2, [220.00, 277.18, 329.63, 440.00], 0.15),
        (34.0, 4.2, [196.00, 246.94, 329.63, 392.00], 0.16),
        # Scene 6 (38-47s): Human Approval (Focused anticipation -> Warm resolution at 42.2s)
        (38.0, 4.3, [146.83, 220.00, 293.66, 392.00], 0.14),
        (42.2, 5.0, [146.83, 220.00, 293.66, 369.99, 440.00, 587.33], 0.18),
        # Scene 7 (47-55s): The Growth Operating System (Expansive architectural pullback)
        (47.0, 4.2, [196.00, 293.66, 369.99, 440.00, 587.33], 0.18),
        (51.0, 4.2, [220.00, 329.63, 392.00, 493.88, 659.25], 0.18),
        # Scene 8 (55-62s): Brand Finale (Confident D Major 9th sonic signature)
        (55.0, 7.0, [146.83, 220.00, 293.66, 369.99, 440.00, 587.33, 659.25], 0.20),
    ]
    for st, cdur, cfreqs, camp in chords:
        wl, wr = synth_warm_pad_chord(cfreqs, cdur, amp=camp)
        add_event(buf_l, buf_r, st, wl, wr)

    # 2. Tactile Editorial Pulse (Gentle marimba/mallet arpeggio giving rhythmic motion)
    arp_scale = [293.66, 329.63, 369.99, 440.00, 587.33, 440.00, 369.99, 329.63]
    step_sec = 0.25  # 120 BPM sixteenth/eighth feel
    for idx in range(int(60.5 / step_sec)):
        t_pos = idx * step_sec
        # Pause arpeggio briefly right before human approval click (41.2..42.2s) for dramatic focus
        if 41.0 <= t_pos < 42.2:
            continue
        freq = arp_scale[idx % len(arp_scale)]
        pan = 0.32 + 0.36 * ((idx % 3) / 2.0)
        amp = 0.055 if t_pos < 6.0 else (0.075 if t_pos < 55.0 else 0.065)
        nl, nr = synth_tactile_marimba_note(freq, duration=0.32, amp=amp, pan=pan)
        add_event(buf_l, buf_r, t_pos, nl, nr)

    # 3. Synchronized Low-Frequency Scene Reveal Accents
    reveal_times = [0.1, 6.0, 13.0, 22.0, 30.0, 38.0, 47.0, 55.0]
    for rt in reveal_times:
        al, ar = synth_low_reveal_accent(freq=73.42, dur=1.5, amp=0.14)
        add_event(buf_l, buf_r, rt, al, ar)

    # 4. Synchronized Card Placement & Interface Clicks matched to visual storyboard events
    card_events = [
        # Scene 1 business signal cues
        (1.35, 0.3), (1.67, 0.45), (1.99, 0.55), (2.31, 0.7),
        # Scene 2 hero & floating panels
        (6.15, 0.5), (8.10, 0.7), (8.38, 0.7), (8.66, 0.3),
        # Scene 3 specialist workstations
        (13.55, 0.25), (13.83, 0.5), (14.11, 0.75),
        # Scene 4 Growth Radar opportunity cards
        (22.65, 0.65), (23.00, 0.65), (23.35, 0.65), (23.70, 0.65),
        # Scene 5 Debate findings & synthesis
        (30.85, 0.45), (31.45, 0.45), (32.35, 0.75),
        # Scene 6 Approval card entrance
        (38.20, 0.4), (39.20, 0.75),
        # Scene 7 6-surface OS grid
        (47.25, 0.3), (47.41, 0.5), (47.57, 0.7), (47.73, 0.3), (47.89, 0.5), (48.05, 0.7),
        # Scene 8 Finale panels
        (55.75, 0.25), (55.97, 0.75), (56.19, 0.75),
    ]
    for ct, cpan in card_events:
        cl, cr = synth_card_placement(amp=0.085, pan=cpan)
        add_event(buf_l, buf_r, ct, cl, cr)

    # 5. Restrained Rising Harmonic Tones for Growth Radar visualization (Scene 4: 23.0s - 25.5s)
    radar_tones = [440.0, 493.88, 587.33, 659.25, 739.99, 880.0]
    for idx, rf in enumerate(radar_tones):
        tl, tr_sig = synth_tactile_marimba_note(rf, duration=0.45, amp=0.065, pan=0.35 + idx * 0.06)
        add_event(buf_l, buf_r, 23.2 + idx * 0.32, tl, tr_sig)

    # 6. Scene 6 Centerpiece Event: Human Cursor Clicks "Approve" at t = 42.20s
    u_l, u_r = synth_ui_click(amp=0.14, pan=0.42)
    add_event(buf_l, buf_r, 42.20, u_l, u_r)
    ch_l, ch_r = synth_approval_chime(amp=0.16)
    add_event(buf_l, buf_r, 42.24, ch_l, ch_r)

    # 7. Scene 8 Closing Sonic Signature (t = 56.5s)
    sig_l, sig_r = synth_approval_chime(amp=0.15)
    add_event(buf_l, buf_r, 56.50, sig_l, sig_r)

    # Smooth fade-in (0.2s) and gentle closing fade-out (last 0.6s)
    fade_in = int(0.2 * SR)
    fade_out = int(0.65 * SR)
    buf_l[:fade_in] *= np.linspace(0, 1, fade_in)
    buf_r[:fade_in] *= np.linspace(0, 1, fade_in)
    buf_l[-fade_out:] *= np.linspace(1, 0, fade_out) ** 1.5
    buf_r[-fade_out:] *= np.linspace(1, 0, fade_out) ** 1.5

    # Soft limiter to prevent any clipping (peak at -1.5 dBFS = 0.84)
    peak = max(np.max(np.abs(buf_l)), np.max(np.abs(buf_r)), 1e-6)
    norm_gain = min(1.0, 0.84 / peak) if peak > 0.84 else (0.78 / peak)
    buf_l *= norm_gain
    buf_r *= norm_gain

    _write_stereo_wav(filepath, buf_l, buf_r)
    return buf_l, buf_r


def _write_stereo_wav(filepath: str, buf_l: np.ndarray, buf_r: np.ndarray):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    stereo = np.empty((len(buf_l), 2), dtype=np.int16)
    stereo[:, 0] = np.clip(buf_l * 32767.0, -32767, 32767).astype(np.int16)
    stereo[:, 1] = np.clip(buf_r * 32767.0, -32767, 32767).astype(np.int16)
    with wave.open(filepath, "wb") as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(SR)
        wf.writeframes(stereo.tobytes())


def generate_all_audio(base_dir: str):
    full_wav = os.path.join(base_dir, "audio", "razorgrowth_launch_62s.wav")
    preview_wav = os.path.join(base_dir, "audio", "razorgrowth_preview_24s.wav")
    teaser_wav = os.path.join(base_dir, "audio", "razorgrowth_teaser_15s.wav")

    full_l, full_r = generate_full_62s_score(full_wav)

    # Preview reel is 24.0s (4 representative 6s segments: Scene 1, Scene 3, Scene 6, Scene 8)
    s1 = slice(int(0.0 * SR), int(6.0 * SR))
    s3 = slice(int(13.0 * SR), int(19.0 * SR))
    s6 = slice(int(39.0 * SR), int(45.0 * SR))
    s8 = slice(int(55.5 * SR), int(61.5 * SR))
    prev_l = np.concatenate([full_l[s1], full_l[s3], full_l[s6], full_l[s8]])
    prev_r = np.concatenate([full_r[s1], full_r[s3], full_r[s6], full_r[s8]])
    _write_stereo_wav(preview_wav, prev_l, prev_r)

    # Teaser is 15.0s (0-3s Scene 1, 3-6.5s Scene 3, 6.5-10.5s Scene 6, 10.5-15s Scene 8)
    t1 = slice(int(1.0 * SR), int(4.0 * SR))
    t2 = slice(int(13.5 * SR), int(17.0 * SR))
    t3 = slice(int(40.0 * SR), int(44.0 * SR))
    t4 = slice(int(56.5 * SR), int(61.0 * SR))
    teas_l = np.concatenate([full_l[t1], full_l[t2], full_l[t3], full_l[t4]])
    teas_r = np.concatenate([full_r[t1], full_r[t2], full_r[t3], full_r[t4]])
    _write_stereo_wav(teaser_wav, teas_l, teas_r)
    print("Synthesized 48 kHz stereo audio tracks:", full_wav, preview_wav, teaser_wav)


if __name__ == "__main__":
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    generate_all_audio(project_root)
