"""
RazorGrowth AI — Strict Brand Design System & Color/Typography Tokens
"""

# Frame & Timeline Specifications
WIDTH = 1920
HEIGHT = 1080
FPS = 30
TOTAL_DURATION = 62.0
TOTAL_FRAMES = int(TOTAL_DURATION * FPS)  # 1860 frames
TEASER_DURATION = 15.0
TEASER_FRAMES = int(TEASER_DURATION * FPS)  # 450 frames

# Exact Brand Color Palette (Normalized RGB 0..1 for PyCairo & Hex strings)
HEX_PALETTE = {
    "parchment": "#F7ECD9",       # Warm parchment / page background
    "sky_top": "#F3D9BC",         # Warm peach sky upper tone
    "sky_bottom": "#F7ECD9",      # Warm parchment horizon
    "cream": "#FFF3E1",           # Main warm cream surface
    "cream_soft": "#FDF6EC",      # Elevated highlight cream
    "espresso": "#26150F",        # Dark espresso / title bars / primary text
    "espresso_muted": "#422A20",  # Secondary structural stroke
    "terracotta": "#C65D42",      # Terracotta / primary actions / emphasized words
    "terracotta_dark": "#9E432C", # Shaded 3D terracotta side
    "coral": "#DA8064",           # Soft coral / secondary accent
    "sage": "#5D8F6D",            # Muted sage / success & status indicators
    "sage_light": "#CFE0D3",      # Soft sage badge fill
    "sage_ground": "#8CA88E",     # Muted sage ground plane
    "dusty_green": "#6E8B74",     # Foreground dusty green hill/foliage
    "taupe": "#8F7561",           # Warm taupe / secondary typography
    "sand": "#D9B993",            # Sand / card shadows / architectural accents
    "sand_dark": "#C29F77",       # Shaded sand architectural side
    "slate": "#7C8588",           # Muted slate / secondary interface indicators
    "ochre": "#D4943A",           # Warm ochre / Designer Agent specialist accent
    "ochre_light": "#F5E3C3",     # Soft ochre surface tint
}


def hex_to_rgb(hex_str: str):
    h = hex_str.lstrip("#")
    return (
        int(h[0:2], 16) / 255.0,
        int(h[2:4], 16) / 255.0,
        int(h[4:6], 16) / 255.0,
    )


COLORS = {k: hex_to_rgb(v) for k, v in HEX_PALETTE.items()}

# Typography Families (Verified available in runtime environment)
FONT_DISPLAY = "Inter Display"
FONT_SANS = "Inter"
FONT_MONO = "Liberation Mono"

# Preferred Type Sizes for 1920x1080 Composition
TYPE_SCALE = {
    "hero_xl": 96,          # 88-116 px main launch headline
    "hero_lg": 88,          # Large hero headline
    "headline_md": 58,      # 48-70 px secondary headlines
    "headline_sm": 48,      # Section headline
    "subcopy_lg": 30,       # 25-34 px supporting copy
    "subcopy_md": 26,       # Supporting subtitle
    "ui_title": 22,         # 20-27 px interface card heading
    "ui_body": 20,          # 20-27 px interface body text
    "ui_label": 16,         # 14-20 px labels and metadata
    "ui_micro": 14,         # 14-20 px compact uppercase metadata
}

# Scene Timing Table (Seconds)
SCENES = [
    {"id": 1, "name": "THE BUSINESS WORLD", "start": 0.0, "end": 6.0},
    {"id": 2, "name": "PRODUCT REVEAL", "start": 6.0, "end": 13.0},
    {"id": 3, "name": "MEET THE AI TEAM", "start": 13.0, "end": 22.0},
    {"id": 4, "name": "GROWTH RADAR", "start": 22.0, "end": 30.0},
    {"id": 5, "name": "INVESTIGATE, DEBATE, SYNTHESIZE", "start": 30.0, "end": 38.0},
    {"id": 6, "name": "HUMAN APPROVAL", "start": 38.0, "end": 47.0},
    {"id": 7, "name": "THE GROWTH OPERATING SYSTEM", "start": 47.0, "end": 55.0},
    {"id": 8, "name": "BRAND FINALE", "start": 55.0, "end": 62.0},
]
