"""
RazorGrowth AI — Motion Design Easing & Timeline Interpolation Utilities
"""
import math


def clamp(val: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, val))


def norm_time(t: float, start: float, end: float) -> float:
    if end <= start:
        return 1.0 if t >= end else 0.0
    return clamp((t - start) / (end - start), 0.0, 1.0)


def lerp(a: float, b: float, u: float) -> float:
    return a + (b - a) * u


def lerp_tuple(t1, t2, u: float):
    return tuple(lerp(a, b, u) for a, b in zip(t1, t2))


def ease_in_out_cubic(u: float) -> float:
    u = clamp(u)
    return 4.0 * u * u * u if u < 0.5 else 1.0 - pow(-2.0 * u + 2.0, 3) / 2.0


def ease_out_cubic(u: float) -> float:
    u = clamp(u)
    return 1.0 - pow(1.0 - u, 3)


def ease_in_cubic(u: float) -> float:
    u = clamp(u)
    return u * u * u


def ease_out_quint(u: float) -> float:
    u = clamp(u)
    return 1.0 - pow(1.0 - u, 5)


def ease_in_out_quint(u: float) -> float:
    u = clamp(u)
    return 16.0 * (u ** 5) if u < 0.5 else 1.0 - pow(-2.0 * u + 2.0, 5) / 2.0


def ease_out_back(u: float, overshoot: float = 1.15) -> float:
    """Subtle physical overshoot for rising cards and 3D workstations."""
    u = clamp(u)
    c1 = overshoot
    c3 = c1 + 1.0
    return 1.0 + c3 * pow(u - 1.0, 3) + c1 * pow(u - 1.0, 2)


def ease_anticipation_out(u: float) -> float:
    """Slight anticipation dip (-0.04) before smooth forward acceleration."""
    u = clamp(u)
    if u < 0.18:
        s = u / 0.18
        return -0.04 * math.sin(s * math.pi)
    s = (u - 0.18) / 0.82
    return ease_in_out_cubic(s)


def stagger(t: float, base_start: float, duration: float, index: int, step: float = 0.12) -> float:
    """Staggered normalized progress for sequential UI cards or headlines."""
    s = base_start + index * step
    return ease_out_cubic(norm_time(t, s, s + duration))
