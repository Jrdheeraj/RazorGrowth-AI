"""
SCENE 3 — MEET THE AI TEAM (00:13–00:22)
- Hero window separates into three floating specialist workstations + 15-agent architectural ecosystem.
- Featured roles:
  * Marketing Agent (Terracotta #C65D42): customer segments, retention, win-back, email campaign drafts.
  * Product Agent (Muted Sage #5D8F6D): product performance, affinity, bundling, pricing signals, inventory risk.
  * Designer Agent (Warm Ochre #D4943A): creative briefs, visual assets, UX findings for review.
- Represented as original 3D sculptural geometric desk companions on miniature 3D pedestals.
- Includes 15-agent 3-generation ecosystem bar so it is clear 15 agents exist across 3 generations.
- On-screen text:
  "Specialized intelligence."
  Then: "One coordinated growth team."
"""
import math
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_MONO
from src.animations.easing import norm_time, ease_out_cubic, ease_in_out_cubic, stagger
from src.engine.camera3d import Camera3D, Scene3DRenderer
from src.components.ui_kit import draw_masked_headline, draw_pill_badge
from src.components.agents3d import (
    add_sculptural_agent_companion,
    draw_specialist_workstation_panel,
    draw_15_agent_ecosystem_bar,
)


def render_scene3(ctx: cairo.Context, t: float):
    # Global t in [13.0..22.0], local lt in [0.0..9.0]
    lt = t - 13.0
    u = norm_time(t, 13.0, 22.0)

    # 1. Warm parchment background with subtle architectural floor grid
    ctx.save()
    pr, pg, pb = COLORS["parchment"]
    ctx.set_source_rgb(pr, pg, pb)
    ctx.paint()

    # Subtle radial warm cream studio glow
    rad = cairo.RadialGradient(WIDTH * 0.5, HEIGHT * 0.52, 80, WIDTH * 0.5, HEIGHT * 0.52, 880)
    cr, cg, cb = COLORS["cream"]
    rad.add_color_stop_rgba(0.0, cr, cg, cb, 0.85)
    rad.add_color_stop_rgba(1.0, pr, pg, pb, 0.0)
    ctx.set_source(rad)
    ctx.rectangle(0, 0, WIDTH, HEIGHT)
    ctx.fill()
    ctx.restore()

    # 2. 3D Camera & Sculptural Agent Workstations in 3D space
    orbit_ang = (u - 0.5) * 0.26
    cam = Camera3D(
        pos=(math.sin(orbit_ang) * 160.0, 145.0, -640.0),
        target=(0.0, 25.0, 0.0),
        fov=960.0,
        cx=WIDTH * 0.5,
        cy=HEIGHT * 0.43,
    )
    r3d = Scene3DRenderer(ctx, cam)

    # 3D Architectural floor platform connecting the three workstations
    r3d.add_box(
        center=(0.0, -56.0, 20.0),
        size=(960.0, 8.0, 280.0),
        base_rgb=COLORS["sand"],
        top_rgb=COLORS["parchment"],
        stroke_rgb=COLORS["espresso"],
        stroke_width=1.4,
        alpha=0.88,
        contact_shadow=False,
    )

    # Three 3D Sculptural Agent Companions (Marketing, Product, Designer)
    agent_positions = [
        (-330.0, 0.0, 0.0, "marketing", 0),
        (0.0, 0.0, -25.0, "product", 1),
        (330.0, 0.0, 0.0, "designer", 2),
    ]
    for ax, ay, az, role, idx in agent_positions:
        ap = stagger(lt, base_start=0.15, duration=0.95, index=idx, step=0.25)
        add_sculptural_agent_companion(
            r3d,
            center=(ax, ay - (1.0 - ap) * 45.0, az),
            role=role,
            t=t,
            scale=1.08,
            alpha=ap,
        )

    # Subtle 3D background ecosystem nodes (12 additional specialist nodes in an upper arc)
    eco_p = ease_out_cubic(norm_time(lt, 1.4, 2.8))
    if eco_p > 0.01:
        for i in range(12):
            ang = -math.pi * 0.82 + (math.pi * 0.64 * i) / 11.0
            nx = math.sin(ang) * 520.0
            nz = 160.0 + math.cos(ang) * 110.0
            ny = 78.0 + math.sin(t * 2.0 + i) * 4.0
            col_key = "terracotta" if i % 3 == 0 else ("sage" if i % 3 == 1 else "ochre")
            r3d.add_box(
                center=(nx, ny, nz),
                size=(14.0, 14.0, 14.0),
                base_rgb=COLORS[col_key],
                top_rgb=COLORS["cream"],
                stroke_rgb=COLORS["espresso"],
                stroke_width=1.1,
                alpha=0.72 * eco_p,
                rot_y=t * 0.5 + i,
                contact_shadow=False,
            )

    # Structured workflow connection lines between Marketing -> Product -> Designer pedestals
    conn_p = ease_in_out_cubic(norm_time(lt, 1.8, 3.4))
    if conn_p > 0.01:
        r3d.add_line3d((-250.0, -18.0, 0.0), (-80.0, -18.0, -20.0), COLORS["terracotta"], width=2.6, alpha=conn_p, progress=conn_p)
        r3d.add_line3d((80.0, -18.0, -20.0), (250.0, -18.0, 0.0), COLORS["sage"], width=2.6, alpha=conn_p, progress=conn_p)

    r3d.render()

    # 3. Top Headlines:
    # First: "Specialized intelligence." (00:13.3 -> 00:17.2)
    # Second: "One coordinated growth team." (00:16.5 -> 00:22.0)
    draw_pill_badge(
        ctx,
        x=100,
        y=48,
        text="AI TEAM · FEATURED SPECIALISTS & 15-AGENT ARCHITECTURE",
        bg_key="cream",
        fg_key="espresso",
        dot_key="terracotta",
        alpha=ease_out_cubic(norm_time(lt, 0.1, 0.8)),
        font_size=13.0,
    )

    p_h1 = ease_out_cubic(norm_time(lt, 0.35, 1.25))
    p_h2 = ease_out_cubic(norm_time(lt, 3.20, 4.15))

    draw_masked_headline(
        ctx,
        x=100,
        y=124,
        text="Specialized intelligence.",
        size=54.0,
        color_key="espresso",
        progress=p_h1,
        align="left",
    )
    draw_masked_headline(
        ctx,
        x=785,
        y=124,
        text="One coordinated growth team.",
        size=54.0,
        color_key="terracotta",
        progress=p_h2,
        align="left",
    )

    # 4. Three Browser-Like Specialist Workstation Windows below the 3D companions
    panel_w = 532.0
    panel_h = 285.0
    panel_y = 585.0

    # Marketing Agent Workstation
    m_p = stagger(lt, base_start=0.55, duration=0.9, index=0, step=0.28)
    draw_specialist_workstation_panel(
        ctx,
        x=100,
        y=panel_y,
        w=panel_w,
        h=panel_h,
        role_title="Marketing Agent · Specialist",
        window_slug="marketing-agent — segments.app",
        accent_key="terracotta",
        tasks=[
            ("Customer Segment & Retention Scan", "SIGNAL: Repeat cohort churn window identified"),
            ("Win-Back Opportunity Analysis", "PLANNING: High-affinity lapsed buyer segment"),
            ("Email Campaign Draft Prepared", "STATUS: Queued for structured synthesis & review"),
        ],
        active_idx=int(lt * 1.1) % 3,
        progress=m_p,
        t=t,
    )

    # Product Agent Workstation
    p_p = stagger(lt, base_start=0.55, duration=0.9, index=1, step=0.28)
    draw_specialist_workstation_panel(
        ctx,
        x=694,
        y=panel_y,
        w=panel_w,
        h=panel_h,
        role_title="Product Agent · Specialist",
        window_slug="product-agent — catalog.app",
        accent_key="sage",
        tasks=[
            ("Product Performance & Affinity", "SIGNAL: Co-purchase pairing across core SKUs"),
            ("Bundling & Pricing Signal Check", "ANALYSIS: Margin-safe bundle configuration"),
            ("Inventory Risk Verification", "SAFEGUARD: Stock buffer verified before campaign"),
        ],
        active_idx=int(lt * 1.1 + 1) % 3,
        progress=p_p,
        t=t,
    )

    # Designer Agent Workstation
    d_p = stagger(lt, base_start=0.55, duration=0.9, index=2, step=0.28)
    draw_specialist_workstation_panel(
        ctx,
        x=1288,
        y=panel_y,
        w=panel_w,
        h=panel_h,
        role_title="Designer Agent · Specialist",
        window_slug="designer-agent — studio.app",
        accent_key="ochre",
        tasks=[
            ("Creative Brief Assembly", "BRIEF: Editorial visual hierarchy & offer framing"),
            ("Original Visual Asset Layout", "ASSET: Storefront & campaign card composition"),
            ("UX Findings for Human Review", "AUDIT: Checkout clarity & mobile tap targets"),
        ],
        active_idx=int(lt * 1.1 + 2) % 3,
        progress=d_p,
        t=t,
    )

    # 5. Bottom 15-Agent Ecosystem Bar (explicitly communicating 15 agents across 3 generations)
    bar_p = ease_out_cubic(norm_time(lt, 1.9, 2.9))
    draw_15_agent_ecosystem_bar(
        ctx,
        x=100,
        y=900,
        w=1720,
        h=64,
        t=t,
        alpha=bar_p,
    )
