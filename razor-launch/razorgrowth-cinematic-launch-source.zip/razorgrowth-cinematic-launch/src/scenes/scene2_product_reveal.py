"""
SCENE 2 — PRODUCT REVEAL (00:06–00:13)
- Main cream browser window rises into view with dark espresso title bar: "razorgrowth — welcome.app"
- Oversized hero window + 3 smaller floating product panels against the warm illustrated business landscape.
- Timed typographic movements:
  "Run your growth engine with"
  "AI employees." (in terracotta #C65D42)
- Supporting text:
  "Find opportunities. Plan actions. Execute with human approval."
"""
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_SANS, FONT_MONO
from src.animations.easing import norm_time, ease_out_cubic, ease_out_back, ease_in_out_cubic, stagger
from src.components.environment import draw_business_neighborhood
from src.components.ui_kit import (
    draw_browser_window,
    draw_card,
    draw_button,
    draw_pill_badge,
    draw_masked_headline,
    draw_line_chart,
)


def render_scene2(ctx: cairo.Context, t: float):
    lt = t - 6.0
    u = norm_time(t, 6.0, 13.0)

    # 1. Background illustrated business neighborhood (extruded 3D depth retained)
    draw_business_neighborhood(
        ctx,
        t=t,
        cam_push=0.16 + 0.08 * ease_in_out_cubic(u),
        extrude_3d=1.0,
        pan_x=30.0 * (1.0 - u),
        horizon_y=790.0,
        alpha=1.0,
    )

    # 2. Main Hero Browser Window centered cleanly between flanking floating panels
    win_p = ease_out_back(norm_time(lt, 0.05, 1.05), overshoot=1.06)
    win_alpha = ease_out_cubic(norm_time(lt, 0.0, 0.65))
    win_w, win_h = 1100.0, 610.0
    win_x = (WIDTH - win_w) * 0.5
    win_y = 110.0 + (1.0 - win_p) * 95.0

    draw_browser_window(
        ctx,
        x=win_x,
        y=win_y,
        w=win_w,
        h=win_h,
        title="razorgrowth — welcome.app",
        alpha=win_alpha,
        shadow_offset=12.0,
        corner_r=7.0,
        header_h=42.0,
        bg_key="cream",
        tag_right="GROWTH OS · V3",
    )

    if win_alpha > 0.1:
        ctx.save()
        er, eg, eb = COLORS["espresso"]
        tr, tg, tb = COLORS["taupe"]
        nav_y = win_y + 72
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(13.5)
        ctx.set_source_rgba(er, eg, eb, win_alpha)
        ctx.move_to(win_x + 48, nav_y)
        ctx.show_text("RAZORGROWTH AI")

        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        nav_items = ["GROWTH RADAR", "AI EMPLOYEES (15)", "AGENT DEBATES", "HUMAN APPROVAL", "BI OVERVIEW"]
        nx = win_x + 240
        for item in nav_items:
            ctx.set_source_rgba(tr, tg, tb, 0.9 * win_alpha)
            ctx.move_to(nx, nav_y)
            ctx.show_text(item)
            nx += ctx.text_extents(item).width + 30

        ctx.set_source_rgba(er, eg, eb, 0.16 * win_alpha)
        ctx.set_line_width(1.2)
        ctx.new_path()
        ctx.move_to(win_x + 36, nav_y + 18)
        ctx.line_to(win_x + win_w - 36, nav_y + 18)
        ctx.stroke()
        ctx.restore()

    # 3. Three timed typographic movements inside hero window
    p_line1 = ease_out_cubic(norm_time(lt, 0.65, 1.55))
    p_line2 = ease_out_cubic(norm_time(lt, 1.25, 2.15))
    p_sub = ease_out_cubic(norm_time(lt, 1.95, 2.85))
    p_cta = ease_out_cubic(norm_time(lt, 2.40, 3.20))

    draw_pill_badge(
        ctx,
        x=win_x + 52,
        y=win_y + 112,
        text="COORDINATED AI GROWTH OPERATING SYSTEM",
        bg_key="parchment",
        fg_key="espresso",
        dot_key="terracotta",
        alpha=p_line1,
        font_size=13.0,
    )

    draw_masked_headline(
        ctx,
        x=win_x + 52,
        y=win_y + 220,
        text="Run your growth engine with",
        size=68.0,
        color_key="espresso",
        progress=p_line1,
        align="left",
    )

    draw_masked_headline(
        ctx,
        x=win_x + 52,
        y=win_y + 306,
        text="AI employees.",
        size=84.0,
        color_key="terracotta",
        progress=p_line2,
        align="left",
    )

    if p_sub > 0.01:
        ctx.save()
        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(25.5)
        er, eg, eb = COLORS["espresso"]
        ctx.set_source_rgba(er, eg, eb, 0.88 * p_sub)
        ctx.move_to(win_x + 52, win_y + 368)
        ctx.show_text("Find opportunities. Plan actions. Execute with human approval.")

        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(18.5)
        tr, tg, tb = COLORS["taupe"]
        ctx.set_source_rgba(tr, tg, tb, p_sub)
        ctx.move_to(win_x + 52, win_y + 404)
        ctx.show_text(
            "RazorGrowth AI gives your growth team a system of AI employees that finds opportunities,"
        )
        ctx.move_to(win_x + 52, win_y + 430)
        ctx.show_text(
            "collaborates through structured workflows, and prepares actions for human review."
        )
        ctx.restore()

    if p_cta > 0.01:
        draw_button(
            ctx,
            x=win_x + 52,
            y=win_y + 462,
            w=248,
            h=50,
            label="EXPLORE GROWTH OS ->",
            variant="primary",
            alpha=p_cta,
            font_size=15.0,
        )
        draw_button(
            ctx,
            x=win_x + 318,
            y=win_y + 462,
            w=246,
            h=50,
            label="HUMAN APPROVAL GATE",
            variant="secondary",
            alpha=p_cta,
            font_size=15.0,
        )

        ctx.save()
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(12.0)
        tr, tg, tb = COLORS["taupe"]
        ctx.set_source_rgba(tr, tg, tb, p_cta)
        ctx.move_to(win_x + 52, win_y + 558)
        ctx.show_text(
            "SIGNALS  ->  AI INVESTIGATION  ->  SPECIALIST REASONING  ->  OPPORTUNITY DISCOVERY  ->  HUMAN APPROVAL"
        )
        ctx.restore()

    # 4. Three asymmetric floating product panels flanking the hero window (zero text/button overlap)
    # Panel A (Upper Right): AI Team Status
    f1_p = stagger(lt, base_start=2.1, duration=0.85, index=0, step=0.28)
    if f1_p > 0.01:
        px, py = 1545, 145 + (1.0 - f1_p) * 35
        draw_browser_window(
            ctx,
            px,
            py,
            325,
            210,
            title="ai-team.app",
            alpha=f1_p,
            shadow_offset=8.0,
            header_h=30.0,
        )
        roles = [
            ("Marketing Agent", "Customer retention & win-back", "terracotta"),
            ("Product Agent", "Bundle affinity & stock buffer", "sage"),
            ("Designer Agent", "Creative brief & UX review", "ochre"),
        ]
        for idx, (rname, rdesc, rcol) in enumerate(roles):
            ry = py + 44 + idx * 50
            draw_card(ctx, px + 14, ry, 297, 42, bg_key="parchment", accent_key=rcol, shadow_offset=2.0, alpha=f1_p)
            ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(13.5)
            ctx.set_source_rgba(COLORS["espresso"][0], COLORS["espresso"][1], COLORS["espresso"][2], f1_p)
            ctx.move_to(px + 26, ry + 18)
            ctx.show_text(rname)
            ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
            ctx.set_font_size(10.5)
            ctx.set_source_rgba(COLORS["taupe"][0], COLORS["taupe"][1], COLORS["taupe"][2], f1_p)
            ctx.move_to(px + 26, ry + 34)
            ctx.show_text(rdesc)

    # Panel B (Lower Right): Growth Radar Mini Card
    f2_p = stagger(lt, base_start=2.1, duration=0.85, index=1, step=0.28)
    if f2_p > 0.01:
        px, py = 1545, 390 + (1.0 - f2_p) * 35
        draw_browser_window(
            ctx,
            px,
            py,
            325,
            205,
            title="growth-radar.app",
            alpha=f2_p,
            shadow_offset=8.0,
            header_h=30.0,
        )
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(11.0)
        ctx.set_source_rgba(COLORS["taupe"][0], COLORS["taupe"][1], COLORS["taupe"][2], f2_p)
        ctx.move_to(px + 16, py + 50)
        ctx.show_text("9 SIGNAL CATEGORIES · SAMPLE")
        draw_line_chart(
            ctx,
            px + 16,
            py + 64,
            292,
            90,
            [0.25, 0.38, 0.34, 0.56, 0.62, 0.82],
            progress=f2_p,
            stroke_key="terracotta",
            alpha=f2_p,
        )
        draw_pill_badge(
            ctx,
            px + 16,
            py + 166,
            "OPPORTUNITY SURFACED",
            bg_key="parchment",
            fg_key="espresso",
            dot_key="sage",
            alpha=f2_p,
            font_size=10.5,
        )

    # Panel C (Left Flanking): Human Approval Gate Mini Card
    f3_p = stagger(lt, base_start=2.1, duration=0.85, index=2, step=0.28)
    if f3_p > 0.01:
        px, py = 50, 290 + (1.0 - f3_p) * 35
        draw_browser_window(
            ctx,
            px,
            py,
            325,
            190,
            title="approval-gate.app",
            alpha=f3_p,
            shadow_offset=8.0,
            header_h=30.0,
        )
        draw_pill_badge(
            ctx,
            px + 16,
            py + 46,
            "HUMAN REVIEW REQUIRED",
            bg_key="parchment",
            fg_key="espresso",
            dot_key="terracotta",
            alpha=f3_p,
            font_size=11.0,
        )
        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(14.5)
        ctx.set_source_rgba(COLORS["espresso"][0], COLORS["espresso"][1], COLORS["espresso"][2], f3_p)
        ctx.move_to(px + 16, py + 98)
        ctx.show_text("Retention & Bundle Action Plan")
        draw_button(ctx, px + 16, py + 118, 138, 38, "APPROVE", variant="primary", alpha=f3_p, font_size=13.0)
        draw_button(ctx, px + 168, py + 118, 128, 38, "REVIEW", variant="secondary", alpha=f3_p, font_size=13.0)
