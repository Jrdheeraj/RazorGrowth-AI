"""
SCENE 8 — BRAND FINALE (00:55–01:02)
- Return to the illustrated business neighborhood.
- Main RazorGrowth product window floats at the center.
- Surrounding product panels settle into a balanced composition inspired by the homepage.
- Headline:
  "Run your growth engine with"
  "AI employees." (in terracotta #C65D42)
- Supporting line:
  "Find opportunities. Plan actions. Execute with human approval."
- Brand lockup: "RazorGrowth AI"
- Final supporting phrase: "AI growth team · Human approval · Real data"
- Hold the final composition comfortably; end with a warm, gentle closing finish (no sudden cut to black).
"""
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_DISPLAY, FONT_SANS, FONT_MONO
from src.animations.easing import norm_time, ease_out_cubic, ease_out_back, ease_in_out_cubic, stagger
from src.components.environment import draw_business_neighborhood
from src.components.ui_kit import (
    draw_browser_window,
    draw_card,
    draw_button,
    draw_pill_badge,
    draw_masked_headline,
    draw_line_chart,
    rounded_rect_path,
)


def render_scene8(ctx: cairo.Context, t: float):
    lt = t - 55.0
    u = norm_time(t, 55.0, 62.0)

    draw_business_neighborhood(
        ctx,
        t=t,
        cam_push=0.14 * (1.0 - 0.35 * ease_in_out_cubic(u)),
        extrude_3d=0.92,
        pan_x=-18.0 * (1.0 - u),
        horizon_y=800.0,
        alpha=1.0,
    )

    win_p = ease_out_back(norm_time(lt, 0.0, 0.95), overshoot=1.04)
    win_alpha = ease_out_cubic(norm_time(lt, 0.0, 0.55))
    ww, wh = 1140.0, 595.0
    wx = (WIDTH - ww) * 0.5
    wy = 128.0 + (1.0 - win_p) * 55.0

    draw_browser_window(
        ctx,
        x=wx,
        y=wy,
        w=ww,
        h=wh,
        title="razorgrowth — welcome.app",
        alpha=win_alpha,
        shadow_offset=12.0,
        corner_r=7.0,
        header_h=42.0,
        bg_key="cream",
        tag_right="RAZORGROWTH AI · GROWTH OS",
    )

    er, eg, eb = COLORS["espresso"]

    p_lockup = ease_out_cubic(norm_time(lt, 0.25, 1.0))
    if p_lockup > 0.01:
        ctx.save()
        bx, by = wx + 58, wy + 72
        rounded_rect_path(ctx, bx, by, 38, 38, 5.0)
        cr, cg, cb = COLORS["terracotta"]
        ctx.set_source_rgba(cr, cg, cb, p_lockup)
        ctx.fill_preserve()
        ctx.set_source_rgba(er, eg, eb, p_lockup)
        ctx.set_line_width(2.0)
        ctx.stroke()

        ctx.select_font_face(FONT_DISPLAY, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(23.0)
        ctx.set_source_rgba(COLORS["cream"][0], COLORS["cream"][1], COLORS["cream"][2], p_lockup)
        ctx.move_to(bx + 10, by + 27)
        ctx.show_text("R")

        ctx.select_font_face(FONT_DISPLAY, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(34.0)
        ctx.set_source_rgba(er, eg, eb, p_lockup)
        ctx.move_to(bx + 54, by + 30)
        ctx.show_text("RazorGrowth AI")

        draw_pill_badge(
            ctx,
            x=wx + ww - 395,
            y=by + 4,
            text="GROWTH OPERATING SYSTEM",
            bg_key="parchment",
            fg_key="espresso",
            dot_key="sage",
            alpha=p_lockup,
            font_size=12.5,
        )
        ctx.restore()

    p_h1 = ease_out_cubic(norm_time(lt, 0.45, 1.30))
    p_h2 = ease_out_cubic(norm_time(lt, 0.85, 1.75))
    p_sub = ease_out_cubic(norm_time(lt, 1.35, 2.20))
    p_phrase = ease_out_cubic(norm_time(lt, 1.75, 2.65))

    draw_masked_headline(
        ctx,
        x=wx + 58,
        y=wy + 206,
        text="Run your growth engine with",
        size=68.0,
        color_key="espresso",
        progress=p_h1,
        align="left",
    )
    draw_masked_headline(
        ctx,
        x=wx + 58,
        y=wy + 292,
        text="AI employees.",
        size=84.0,
        color_key="terracotta",
        progress=p_h2,
        align="left",
    )

    if p_sub > 0.01:
        ctx.save()
        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(27.0)
        ctx.set_source_rgba(er, eg, eb, 0.90 * p_sub)
        ctx.move_to(wx + 58, wy + 356)
        ctx.show_text("Find opportunities. Plan actions. Execute with human approval.")
        ctx.restore()

    if p_phrase > 0.01:
        draw_card(
            ctx,
            x=wx + 58,
            y=wy + 392,
            w=ww - 116,
            h=72,
            bg_key="parchment",
            accent_key="terracotta",
            shadow_offset=4.0,
            alpha=p_phrase,
        )
        ctx.save()
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(21.0)
        ctx.set_source_rgba(er, eg, eb, p_phrase)
        ctx.move_to(wx + 86, wy + 436)
        ctx.show_text("AI growth team  ·  Human approval  ·  Real data")
        ctx.restore()

        draw_button(
            ctx,
            x=wx + 58,
            y=wy + 492,
            w=270,
            h=52,
            label="RUN YOUR GROWTH ENGINE ->",
            variant="primary",
            alpha=p_phrase,
            font_size=15.0,
        )
        draw_button(
            ctx,
            x=wx + 346,
            y=wy + 492,
            w=250,
            h=52,
            label="HUMAN-APPROVED AI",
            variant="secondary",
            alpha=p_phrase,
            font_size=15.0,
        )

    fl_p = stagger(lt, 0.75, 0.85, 0, 0.22)
    if fl_p > 0.01:
        px, py = 54, 210 + (1.0 - fl_p) * 30
        draw_browser_window(ctx, px, py, 300, 215, "ai-team.app", alpha=fl_p, header_h=30.0)
        for idx, (rn, rc) in enumerate([
            ("Marketing Agent", "terracotta"),
            ("Product Agent", "sage"),
            ("Designer Agent", "ochre"),
        ]):
            ry = py + 44 + idx * 50
            draw_card(ctx, px + 14, ry, 272, 40, bg_key="parchment", accent_key=rc, shadow_offset=2.0, alpha=fl_p)
            ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(14.5)
            ctx.set_source_rgba(er, eg, eb, fl_p)
            ctx.move_to(px + 28, ry + 25)
            ctx.show_text(rn)

    fr1_p = stagger(lt, 0.75, 0.85, 1, 0.22)
    if fr1_p > 0.01:
        px, py = 1566, 175 + (1.0 - fr1_p) * 30
        draw_browser_window(ctx, px, py, 300, 195, "growth-radar.app", alpha=fr1_p, header_h=30.0)
        draw_line_chart(
            ctx,
            px + 18,
            py + 52,
            264,
            95,
            [0.24, 0.36, 0.33, 0.58, 0.68, 0.86],
            progress=fr1_p,
            stroke_key="terracotta",
            alpha=fr1_p,
        )
        draw_pill_badge(
            ctx,
            px + 18,
            py + 156,
            "9 SIGNALS · SAMPLE",
            bg_key="parchment",
            fg_key="espresso",
            dot_key="terracotta",
            alpha=fr1_p,
            font_size=11.0,
        )

    fr2_p = stagger(lt, 0.75, 0.85, 2, 0.22)
    if fr2_p > 0.01:
        px, py = 1566, 415 + (1.0 - fr2_p) * 30
        draw_browser_window(ctx, px, py, 300, 185, "human-approval.app", alpha=fr2_p, header_h=30.0)
        draw_pill_badge(
            ctx,
            px + 16,
            py + 46,
            "HUMAN REVIEW REQUIRED",
            bg_key="parchment",
            fg_key="espresso",
            dot_key="sage",
            alpha=fr2_p,
            font_size=11.0,
        )
        draw_button(ctx, px + 16, py + 92, 132, 40, "APPROVED", variant="approved", alpha=fr2_p, font_size=13.0)
        draw_button(ctx, px + 158, py + 92, 124, 40, "AUDIT LOG", variant="secondary", alpha=fr2_p, font_size=12.5)

    if lt > 6.55:
        veil = ease_in_out_cubic(norm_time(lt, 6.55, 7.0)) * 0.18
        pr, pg, pb = COLORS["parchment"]
        ctx.new_path()
        ctx.set_source_rgba(pr, pg, pb, veil)
        ctx.rectangle(0, 0, WIDTH, HEIGHT)
        ctx.fill()
