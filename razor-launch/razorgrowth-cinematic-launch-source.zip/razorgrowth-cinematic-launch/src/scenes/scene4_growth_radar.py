"""
SCENE 4 — GROWTH RADAR (00:22–00:30)
- Transition into a miniature 3D Growth Radar workstation.
- Interface title bar reads: "growth-radar.app"
- Compact dashboard rises from the cream surface with:
  * Radar-style signal visualization (representing the 9 documented Growth Radar signal types)
  * Opportunity cards with exact required labels:
    - "Customer retention"
    - "Product opportunity"
    - "Inventory risk"
    - "Failed payment signal"
  * A chart drawing itself & a confidence indicator resolving
  * Explicitly marked as sample illustrative data (no invented customer performance claims)
- On-screen text: "See the opportunities others miss."
"""
import math
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_SANS, FONT_MONO
from src.animations.easing import norm_time, ease_out_cubic, ease_out_back, ease_in_out_cubic, stagger
from src.engine.camera3d import Camera3D, Scene3DRenderer
from src.components.ui_kit import (
    draw_browser_window,
    draw_card,
    draw_pill_badge,
    draw_masked_headline,
    draw_line_chart,
    rounded_rect_path,
)


def render_scene4(ctx: cairo.Context, t: float):
    lt = t - 22.0
    u = norm_time(t, 22.0, 30.0)

    pr, pg, pb = COLORS["parchment"]
    ctx.set_source_rgb(pr, pg, pb)
    ctx.paint()

    cam = Camera3D(
        pos=(-180.0 + u * 90.0, 190.0, -650.0),
        target=(0.0, 20.0, 0.0),
        fov=960.0,
        cx=WIDTH * 0.5,
        cy=HEIGHT * 0.54,
    )
    r3d = Scene3DRenderer(ctx, cam)
    r3d.add_box(
        center=(0.0, -175.0, 40.0),
        size=(1180.0, 18.0, 420.0),
        base_rgb=COLORS["sand"],
        top_rgb=COLORS["cream"],
        stroke_rgb=COLORS["espresso"],
        stroke_width=1.6,
        alpha=0.92,
        rot_y=0.06 * (0.5 - u),
        contact_shadow=True,
    )
    r3d.add_cylinder(
        center=(-520.0, -130.0, 10.0),
        radius=34.0,
        height=64.0,
        segments=10,
        base_rgb=COLORS["terracotta"],
        top_rgb=COLORS["coral"],
        stroke_rgb=COLORS["espresso"],
        stroke_width=1.5,
        alpha=0.95,
    )
    r3d.add_octahedron(
        center=(-520.0, -68.0 + math.sin(t * 2.5) * 5.0, 10.0),
        radius=22.0,
        base_rgb=COLORS["cream"],
        stroke_rgb=COLORS["espresso"],
        stroke_width=1.5,
        alpha=0.95,
        rot_y=t * 0.9,
    )
    r3d.render()

    draw_pill_badge(
        ctx,
        x=110,
        y=46,
        text="GROWTH RADAR · 9 SIGNAL TYPES · PRIORITIZED OPPORTUNITY DISCOVERY",
        bg_key="cream",
        fg_key="espresso",
        dot_key="terracotta",
        alpha=ease_out_cubic(norm_time(lt, 0.05, 0.7)),
        font_size=13.0,
    )

    hl_p = ease_out_cubic(norm_time(lt, 0.25, 1.25))
    draw_masked_headline(
        ctx,
        x=110,
        y=124,
        text="See the opportunities others miss.",
        size=58.0,
        color_key="espresso",
        progress=hl_p,
        align="left",
    )

    win_p = ease_out_back(norm_time(lt, 0.15, 1.05), overshoot=1.05)
    win_alpha = ease_out_cubic(norm_time(lt, 0.1, 0.7))
    wx, wy = 110.0, 158.0 + (1.0 - win_p) * 68.0
    ww, wh = 1700.0, 745.0

    draw_browser_window(
        ctx,
        x=wx,
        y=wy,
        w=ww,
        h=wh,
        title="growth-radar.app",
        alpha=win_alpha,
        shadow_offset=12.0,
        corner_r=7.0,
        header_h=40.0,
        bg_key="cream",
        tag_right="SAMPLE ILLUSTRATIVE SIGNALS · NON-CUSTOMER DATA",
    )

    if win_alpha <= 0.05:
        return

    er, eg, eb = COLORS["espresso"]
    tr, tg, tb = COLORS["taupe"]

    dial_card_x = wx + 32
    dial_card_y = wy + 62
    dial_card_w = 620
    dial_card_h = 370
    draw_card(ctx, dial_card_x, dial_card_y, dial_card_w, dial_card_h, bg_key="parchment", shadow_offset=4.0, alpha=win_alpha)

    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(13.0)
    ctx.set_source_rgba(er, eg, eb, win_alpha)
    ctx.move_to(dial_card_x + 20, dial_card_y + 28)
    ctx.show_text("SIGNAL RADAR · 9 DOCUMENTED SIGNAL CATEGORIES")

    rcx = dial_card_x + 195
    rcy = dial_card_y + 205
    max_r = 128.0
    for ring in (0.35, 0.68, 1.0):
        ctx.new_path()
        ctx.arc(rcx, rcy, max_r * ring, 0, math.pi * 2)
        ctx.set_source_rgba(er, eg, eb, 0.16 * win_alpha)
        ctx.set_line_width(1.2)
        ctx.stroke()

    nine_axes = [
        "RETENTION", "AFFINITY", "INVENTORY", "PAYMENTS", "PRICING",
        "WIN-BACK", "BUNDLE", "FUNNEL UX", "VELOCITY",
    ]
    ctx.new_path()
    for i, _ in enumerate(nine_axes):
        ang = -math.pi * 0.5 + (2.0 * math.pi * i) / 9.0
        ex = rcx + math.cos(ang) * max_r
        ey = rcy + math.sin(ang) * max_r
        ctx.move_to(rcx, rcy)
        ctx.line_to(ex, ey)
    ctx.set_source_rgba(er, eg, eb, 0.14 * win_alpha)
    ctx.stroke()

    sweep_ang = -math.pi * 0.5 + lt * 1.45
    ctx.save()
    ctx.new_path()
    ctx.move_to(rcx, rcy)
    ctx.arc(rcx, rcy, max_r, sweep_ang - 0.55, sweep_ang)
    ctx.close_path()
    cr, cg, cb = COLORS["terracotta"]
    ctx.set_source_rgba(cr, cg, cb, 0.18 * win_alpha)
    ctx.fill()
    ctx.new_path()
    ctx.move_to(rcx, rcy)
    ctx.line_to(rcx + math.cos(sweep_ang) * max_r, rcy + math.sin(sweep_ang) * max_r)
    ctx.set_source_rgba(cr, cg, cb, 0.85 * win_alpha)
    ctx.set_line_width(2.2)
    ctx.stroke()
    ctx.restore()

    radar_nodes = [
        (0, 0.82, "terracotta"),
        (1, 0.74, "sage"),
        (2, 0.68, "ochre"),
        (3, 0.78, "terracotta"),
        (6, 0.62, "sage"),
    ]
    for axis_idx, dist, col_k in radar_nodes:
        ang = -math.pi * 0.5 + (2.0 * math.pi * axis_idx) / 9.0
        nx = rcx + math.cos(ang) * (max_r * dist)
        ny = rcy + math.sin(ang) * (max_r * dist)
        col = COLORS[col_k]
        ctx.new_path()
        ctx.arc(nx, ny, 6.0, 0, math.pi * 2)
        ctx.set_source_rgba(col[0], col[1], col[2], win_alpha)
        ctx.fill_preserve()
        ctx.set_source_rgba(er, eg, eb, win_alpha)
        ctx.set_line_width(1.5)
        ctx.stroke()

    leg_x = dial_card_x + 365
    leg_y = dial_card_y + 68
    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(12.0)
    ctx.set_source_rgba(tr, tg, tb, win_alpha)
    ctx.move_to(leg_x, leg_y)
    ctx.show_text("SIGNAL CONFIDENCE RESOLUTION")

    conf_p = ease_in_out_cubic(norm_time(lt, 1.2, 3.8))
    conf_bars = [
        ("Signal Completeness", 0.90, "sage"),
        ("Cohort Sample Depth", 0.84, "terracotta"),
        ("Cross-Agent Alignment", 0.88, "ochre"),
    ]
    for idx, (blabel, bval, bcol) in enumerate(conf_bars):
        by = leg_y + 28 + idx * 62
        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(14.5)
        ctx.set_source_rgba(er, eg, eb, win_alpha)
        ctx.move_to(leg_x, by)
        ctx.show_text(blabel)

        bar_w = 225.0
        rounded_rect_path(ctx, leg_x, by + 10, bar_w, 12, 3.0)
        ctx.set_source_rgba(er, eg, eb, 0.12 * win_alpha)
        ctx.fill()

        fill_w = bar_w * bval * conf_p
        if fill_w > 2:
            rounded_rect_path(ctx, leg_x, by + 10, fill_w, 12, 3.0)
            c_rgb = COLORS[bcol]
            ctx.set_source_rgba(c_rgb[0], c_rgb[1], c_rgb[2], win_alpha)
            ctx.fill_preserve()
            ctx.set_source_rgba(er, eg, eb, 0.85 * win_alpha)
            ctx.set_line_width(1.1)
            ctx.stroke()

    draw_pill_badge(
        ctx,
        leg_x,
        dial_card_y + 295,
        "CONFIDENCE: HIGH (SAMPLE)",
        bg_key="cream",
        fg_key="espresso",
        dot_key="sage",
        alpha=conf_p * win_alpha,
        font_size=12.0,
    )

    chart_card_y = dial_card_y + dial_card_h + 22
    chart_card_h = 262
    draw_card(ctx, dial_card_x, chart_card_y, dial_card_w, chart_card_h, bg_key="parchment", shadow_offset=4.0, alpha=win_alpha)
    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(12.5)
    ctx.set_source_rgba(er, eg, eb, win_alpha)
    ctx.move_to(dial_card_x + 20, chart_card_y + 28)
    ctx.show_text("SIGNAL INTENSITY TRAJECTORY · ILLUSTRATIVE SAMPLE WINDOW")

    chart_prog = ease_in_out_cubic(norm_time(lt, 0.8, 3.6))
    draw_line_chart(
        ctx,
        x=dial_card_x + 24,
        y=chart_card_y + 52,
        w=dial_card_w - 48,
        h=178,
        points_norm=[0.22, 0.30, 0.28, 0.46, 0.54, 0.51, 0.72, 0.84],
        progress=chart_prog,
        stroke_key="terracotta",
        fill_area=True,
        alpha=win_alpha,
    )

    opp_x = wx + 684
    opp_w = 982

    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(13.5)
    ctx.set_source_rgba(er, eg, eb, win_alpha)
    ctx.move_to(opp_x, dial_card_y + 22)
    ctx.show_text("PRIORITIZED GROWTH OPPORTUNITIES · SAMPLE ILLUSTRATIVE SIGNALS")

    opp_cards = [
        (
            "Customer retention",
            "HIGH PRIORITY · MARKETING & CRM SIGNAL",
            "Repeat purchase cadence shifted in 45-day cohort; win-back sequence recommended.",
            "SIGNAL VERIFIED · SAMPLE COHORT",
            "terracotta",
            True,
        ),
        (
            "Product opportunity",
            "BUNDLE AFFINITY · PRODUCT AGENT SIGNAL",
            "High co-purchase pairing identified between flagship starter kit and refill pack.",
            "PAIRING CONFIDENCE: STRONG (SAMPLE)",
            "sage",
            False,
        ),
        (
            "Inventory risk",
            "STOCK THRESHOLD · CATALOG SAFEGUARD",
            "Variant SKU buffer approaching reorder window; hold aggressive ad spend on low stock.",
            "SAFEGUARD ACTIVE · SAMPLE BUFFER",
            "ochre",
            False,
        ),
        (
            "Failed payment signal",
            "CHECKOUT & RENEWAL · RECOVERY SIGNAL",
            "Elevated card retry drop-off detected on recurring orders; recovery prompt ready.",
            "WORKFLOW QUEUED · SAMPLE METRIC",
            "coral",
            False,
        ),
    ]

    for idx, (title, cat, desc, status_txt, acc_col, is_highlighted) in enumerate(opp_cards):
        cp = stagger(lt, base_start=0.65, duration=0.85, index=idx, step=0.35)
        if cp <= 0.01:
            continue
        slide_x = opp_x + (1.0 - cp) * 75.0
        cy = dial_card_y + 38 + idx * 156
        ch = 140.0

        draw_card(
            ctx,
            slide_x,
            cy,
            opp_w,
            ch,
            bg_key="cream_soft" if is_highlighted else "parchment",
            accent_key=acc_col,
            shadow_offset=7.0 if is_highlighted else 4.0,
            alpha=cp * win_alpha,
        )

        if is_highlighted and lt > 2.2:
            rounded_rect_path(ctx, slide_x, cy, opp_w, ch, 4.0)
            cr, cg, cb = COLORS["terracotta"]
            ctx.set_source_rgba(cr, cg, cb, 0.85 * cp)
            ctx.set_line_width(2.6)
            ctx.stroke()

        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(12.0)
        ctx.set_source_rgba(tr, tg, tb, cp * win_alpha)
        ctx.move_to(slide_x + 24, cy + 28)
        ctx.show_text(cat)

        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(24.0)
        ctx.set_source_rgba(er, eg, eb, cp * win_alpha)
        ctx.move_to(slide_x + 24, cy + 62)
        ctx.show_text(title)

        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(16.5)
        ctx.set_source_rgba(er, eg, eb, 0.84 * cp * win_alpha)
        ctx.move_to(slide_x + 24, cy + 94)
        ctx.show_text(desc)

        draw_pill_badge(
            ctx,
            slide_x + opp_w - 315,
            cy + 20,
            status_txt,
            bg_key="cream",
            fg_key="espresso",
            dot_key=acc_col,
            alpha=cp * win_alpha,
            font_size=11.5,
        )
