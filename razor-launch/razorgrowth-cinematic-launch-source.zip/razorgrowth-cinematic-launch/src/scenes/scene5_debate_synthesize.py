"""
SCENE 5 — INVESTIGATE, DEBATE, SYNTHESIZE (00:30–00:38)
- Move through carefully composed floating product panels in a shared analytical workspace.
- Business signals enter from left; two structured findings cards appear:
  1. Supporting evidence (Marketing & Product bundle retention alignment)
  2. Opposing evidence / Concern & uncertainty (Inventory threshold & margin guardrail)
- A central Manager-style coordination panel organizes the findings into a synthesized recommendation.
- On-screen text:
  "Evidence before recommendations."
  Then: "Better decisions through structured reasoning."
"""
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_SANS, FONT_MONO
from src.animations.easing import norm_time, ease_out_cubic, ease_in_out_cubic
from src.engine.camera3d import Camera3D, Scene3DRenderer
from src.components.ui_kit import (
    draw_browser_window,
    draw_card,
    draw_pill_badge,
    draw_masked_headline,
)


def render_scene5(ctx: cairo.Context, t: float):
    lt = t - 30.0
    u = norm_time(t, 30.0, 38.0)

    pr, pg, pb = COLORS["parchment"]
    ctx.set_source_rgb(pr, pg, pb)
    ctx.paint()

    cam = Camera3D(
        pos=((0.5 - u) * 140.0, 175.0, -660.0),
        target=(0.0, 10.0, 0.0),
        fov=960.0,
        cx=WIDTH * 0.5,
        cy=HEIGHT * 0.54,
    )
    r3d = Scene3DRenderer(ctx, cam)
    r3d.add_box(
        center=(0.0, -180.0, 50.0),
        size=(1260.0, 14.0, 380.0),
        base_rgb=COLORS["sand"],
        top_rgb=COLORS["cream"],
        stroke_rgb=COLORS["espresso"],
        stroke_width=1.5,
        alpha=0.88,
        contact_shadow=True,
    )
    r3d.render()

    draw_pill_badge(
        ctx,
        x=100,
        y=46,
        text="AGENT DEBATES · STRUCTURED EVIDENCE COMPARISON & MANAGER SYNTHESIS",
        bg_key="cream",
        fg_key="espresso",
        dot_key="terracotta",
        alpha=ease_out_cubic(norm_time(lt, 0.05, 0.65)),
        font_size=13.0,
    )

    p_h1 = ease_out_cubic(norm_time(lt, 0.25, 1.15))
    p_h2 = ease_out_cubic(norm_time(lt, 3.10, 4.10))

    draw_masked_headline(
        ctx,
        x=100,
        y=120,
        text="Evidence before recommendations.",
        size=48.0,
        color_key="espresso",
        progress=p_h1,
        align="left",
    )
    draw_masked_headline(
        ctx,
        x=925,
        y=120,
        text="Better decisions through structured reasoning.",
        size=44.0,
        color_key="terracotta",
        progress=p_h2,
        align="left",
    )

    # Left Incoming Signals Column
    sig_p = ease_out_cubic(norm_time(lt, 0.3, 1.1))
    sx, sy, sw, sh = 100.0, 185.0, 340.0, 680.0
    draw_browser_window(
        ctx,
        sx,
        sy + (1.0 - sig_p) * 35.0,
        sw,
        sh,
        title="signals-input.app",
        alpha=sig_p,
        shadow_offset=8.0,
        header_h=34.0,
    )

    er, eg, eb = COLORS["espresso"]
    tr, tg, tb = COLORS["taupe"]

    if sig_p > 0.05:
        in_signals = [
            ("SIGNAL 01 · RETENTION", "45-day repeat cohort lapse", "terracotta"),
            ("SIGNAL 02 · AFFINITY", "Starter + Refill pair lift", "sage"),
            ("SIGNAL 03 · INVENTORY", "Variant B stock buffer notice", "ochre"),
            ("SIGNAL 04 · MARGIN", "Discount threshold policy", "slate"),
        ]
        for idx, (stag, sdesc, scol) in enumerate(in_signals):
            cy = sy + 64 + idx * 145
            draw_card(ctx, sx + 18, cy, sw - 36, 122, bg_key="parchment", accent_key=scol, shadow_offset=3.0, alpha=sig_p)
            ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(12.0)
            ctx.set_source_rgba(tr, tg, tb, sig_p)
            ctx.move_to(sx + 34, cy + 32)
            ctx.show_text(stag)

            ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(17.0)
            ctx.set_source_rgba(er, eg, eb, sig_p)
            ctx.move_to(sx + 34, cy + 66)
            ctx.show_text(sdesc)

            draw_pill_badge(
                ctx,
                sx + 34,
                cy + 82,
                "STRUCTURED INPUT",
                bg_key="cream",
                fg_key="espresso",
                dot_key=scol,
                alpha=sig_p,
                font_size=10.5,
            )

    # Middle Column: Two Structured Findings Cards
    f_x = 495.0
    f_w = 625.0
    f_h = 318.0

    # Card A (Top Middle): Supporting Evidence
    f1_p = ease_out_cubic(norm_time(lt, 0.85, 1.85))
    f1_y = 185.0 + (1.0 - f1_p) * 32.0
    draw_browser_window(
        ctx,
        f_x,
        f1_y,
        f_w,
        f_h,
        title="finding-01 — supporting-evidence.app",
        alpha=f1_p,
        shadow_offset=9.0,
        header_h=34.0,
        tag_right="MARKETING + PRODUCT",
    )
    if f1_p > 0.05:
        draw_pill_badge(
            ctx,
            f_x + 22,
            f1_y + 50,
            "SUPPORTING EVIDENCE · COHORT & BUNDLE FIT",
            bg_key="parchment",
            fg_key="espresso",
            dot_key="sage",
            alpha=f1_p,
            font_size=12.0,
        )
        points_1 = [
            "• Repeat buyers in days 35–50 respond strongly to paired refill reminders.",
            "• Core SKU-A + Refill Pack preserves unit margin without broad discounting.",
            "• Email + storefront card sequence aligns with verified consent segments.",
        ]
        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(14.5)
        ctx.set_source_rgba(er, eg, eb, f1_p)
        for idx, pt in enumerate(points_1):
            ctx.move_to(f_x + 22, f1_y + 114 + idx * 42)
            ctx.show_text(pt)

        draw_card(ctx, f_x + 22, f1_y + 238, f_w - 44, 58, bg_key="parchment", accent_key="sage", shadow_offset=2.0, alpha=f1_p)
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(12.0)
        ctx.set_source_rgba(er, eg, eb, f1_p)
        ctx.move_to(f_x + 38, f1_y + 272)
        ctx.show_text("EVIDENCE WEIGHT: STRONG SUPPORT FOR TARGETED WIN-BACK WORKFLOW")

    # Card B (Bottom Middle): Opposing Evidence / Concern & Uncertainty
    f2_p = ease_out_cubic(norm_time(lt, 1.45, 2.45))
    f2_y = 547.0 + (1.0 - f2_p) * 32.0
    draw_browser_window(
        ctx,
        f_x,
        f2_y,
        f_w,
        f_h,
        title="finding-02 — constraint-uncertainty.app",
        alpha=f2_p,
        shadow_offset=9.0,
        header_h=34.0,
        tag_right="RISK & UNCERTAINTY",
    )
    if f2_p > 0.05:
        draw_pill_badge(
            ctx,
            f_x + 22,
            f2_y + 50,
            "OPPOSING EVIDENCE & UNCERTAINTY · CONSTRAINTS",
            bg_key="parchment",
            fg_key="espresso",
            dot_key="terracotta",
            alpha=f2_p,
            font_size=12.0,
        )
        points_2 = [
            "• Secondary Variant-B inventory has a 14-day restock lead time (stockout risk).",
            "• Site-wide percentage discounts would erode margin on unbundled orders.",
            "• Uncertainty: Post-campaign retention lift requires 14-day window check.",
        ]
        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(14.5)
        ctx.set_source_rgba(er, eg, eb, f2_p)
        for idx, pt in enumerate(points_2):
            ctx.move_to(f_x + 22, f2_y + 114 + idx * 42)
            ctx.show_text(pt)

        draw_card(ctx, f_x + 22, f2_y + 238, f_w - 44, 58, bg_key="parchment", accent_key="terracotta", shadow_offset=2.0, alpha=f2_p)
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(12.0)
        ctx.set_source_rgba(er, eg, eb, f2_p)
        ctx.move_to(f_x + 38, f2_y + 272)
        ctx.show_text("GUARDRAIL REQUIRED: EXCLUDE LOW-STOCK VARIANT-B · CAP BUNDLE SCOPE")

    # Right Column: Manager-Style Coordination & Synthesis Panel
    syn_p = ease_out_cubic(norm_time(lt, 2.35, 3.55))
    mx, my, mw, mh = 1175.0, 185.0 + (1.0 - syn_p) * 38.0, 645.0, 680.0
    draw_browser_window(
        ctx,
        mx,
        my,
        mw,
        mh,
        title="manager-synthesis — debate-resolution.app",
        alpha=syn_p,
        shadow_offset=11.0,
        header_h=38.0,
        tag_right="ORCHESTRATED",
    )

    if syn_p > 0.05:
        draw_pill_badge(
            ctx,
            mx + 26,
            my + 58,
            "SYNTHESIZED RECOMMENDATION · SUPPORTED DEBATE WORKFLOW",
            bg_key="parchment",
            fg_key="espresso",
            dot_key="terracotta",
            alpha=syn_p,
            font_size=12.0,
        )

        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(24.0)
        ctx.set_source_rgba(er, eg, eb, syn_p)
        ctx.move_to(mx + 26, my + 124)
        ctx.show_text("Targeted Cohort Win-Back with")
        ctx.move_to(mx + 26, my + 156)
        ctx.show_text("Stock-Guarded Bundle Configuration")

        syn_blocks = [
            (
                "1. ACCEPTED FROM SUPPORTING EVIDENCE",
                "Target 45-day repeat cohort with SKU-A + Refill Pack bundle.",
                "sage",
            ),
            (
                "2. INCORPORATED FROM RISK & UNCERTAINTY",
                "Exclude low-stock Variant-B and hold site-wide discounts.",
                "ochre",
            ),
            (
                "3. NEXT GATE · HUMAN OPERATOR APPROVAL",
                "Action package staged with rationale & sample impact estimate.",
                "terracotta",
            ),
        ]
        for idx, (bhead, bbody, bcol) in enumerate(syn_blocks):
            by = my + 190 + idx * 136
            draw_card(ctx, mx + 26, by, mw - 52, 116, bg_key="parchment", accent_key=bcol, shadow_offset=4.0, alpha=syn_p)
            ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(12.0)
            ctx.set_source_rgba(tr, tg, tb, syn_p)
            ctx.move_to(mx + 44, by + 34)
            ctx.show_text(bhead)

            ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(15.5)
            ctx.set_source_rgba(er, eg, eb, syn_p)
            ctx.move_to(mx + 44, by + 72)
            ctx.show_text(bbody)

        draw_pill_badge(
            ctx,
            mx + 26,
            my + 612,
            "STATUS: READY FOR HUMAN REVIEW GATE ->",
            bg_key="cream",
            fg_key="espresso",
            dot_key="terracotta",
            alpha=syn_p,
            font_size=12.5,
        )

    line_p1 = ease_in_out_cubic(norm_time(lt, 0.9, 2.0))
    line_p2 = ease_in_out_cubic(norm_time(lt, 2.2, 3.4))

    ctx.save()
    cr, cg, cb = COLORS["terracotta"]
    sr, sg, sb = COLORS["sage"]

    if line_p1 > 0.01:
        ctx.set_source_rgba(er, eg, eb, 0.65 * line_p1)
        ctx.set_line_width(2.2)
        ctx.new_path()
        for start_y, end_y in [(310, 340), (610, 700)]:
            ex = 440 + (f_x - 440) * line_p1
            ey = start_y + (end_y - start_y) * line_p1
            ctx.move_to(440, start_y)
            ctx.line_to(ex, ey)
        ctx.stroke()

    if line_p2 > 0.01:
        ctx.set_source_rgba(sr, sg, sb, 0.9 * line_p2)
        ctx.set_line_width(2.8)
        ex = (f_x + f_w) + (mx - (f_x + f_w)) * line_p2
        ctx.new_path()
        ctx.move_to(f_x + f_w, 344)
        ctx.line_to(ex, 410)
        ctx.stroke()

        ctx.set_source_rgba(cr, cg, cb, 0.9 * line_p2)
        ctx.new_path()
        ctx.move_to(f_x + f_w, 706)
        ctx.line_to(ex, 550)
        ctx.stroke()
    ctx.restore()
