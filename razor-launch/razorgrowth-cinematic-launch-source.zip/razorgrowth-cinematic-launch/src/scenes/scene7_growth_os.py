"""
SCENE 7 — THE GROWTH OPERATING SYSTEM (00:47–00:55)
- Pull back from the approval interface into a wider miniature 3D architectural environment.
- Reveal Growth Radar, AI Team, Agent Debates, Actions, Business Intelligence & Measurement,
  and Checkout product surfaces as coordinated windows.
- Smooth camera orbit followed by a confident pullback.
- On-screen text:
  "Discover. Decide. Act."
  Supporting text: "One growth operating system."
"""
import math
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_SANS, FONT_MONO
from src.animations.easing import norm_time, ease_out_cubic, ease_in_out_cubic, stagger
from src.engine.camera3d import Camera3D, Scene3DRenderer
from src.components.ui_kit import (
    draw_browser_window,
    draw_card,
    draw_pill_badge,
    draw_masked_headline,
    draw_line_chart,
    draw_button,
)
from src.components.agents3d import add_sculptural_agent_companion


def render_scene7(ctx: cairo.Context, t: float):
    lt = t - 47.0
    u = norm_time(t, 47.0, 55.0)

    pr, pg, pb = COLORS["parchment"]
    ctx.set_source_rgb(pr, pg, pb)
    ctx.paint()

    pullback = ease_in_out_cubic(u)
    orbit_ang = (0.5 - u) * 0.42
    cam_dist = -620.0 - pullback * 190.0
    cam_y = 195.0 + pullback * 65.0

    cam = Camera3D(
        pos=(math.sin(orbit_ang) * 240.0, cam_y, cam_dist),
        target=(0.0, -10.0, 40.0),
        fov=960.0,
        cx=WIDTH * 0.5,
        cy=HEIGHT * 0.52,
    )
    r3d = Scene3DRenderer(ctx, cam)

    r3d.add_box(
        center=(0.0, -155.0, 60.0),
        size=(1340.0, 18.0, 560.0),
        base_rgb=COLORS["sand"],
        top_rgb=COLORS["cream"],
        stroke_rgb=COLORS["espresso"],
        stroke_width=1.5,
        alpha=0.90,
        contact_shadow=True,
    )

    campus_blocks = [
        (-480.0, -110.0, 150.0, (110.0, 72.0, 90.0), "cream", "terracotta"),
        (-220.0, -115.0, 180.0, (125.0, 62.0, 95.0), "parchment", "sand"),
        (220.0, -115.0, 180.0, (125.0, 62.0, 95.0), "cream", "terracotta"),
        (480.0, -110.0, 150.0, (110.0, 72.0, 90.0), "parchment", "sand"),
    ]
    for bx, by, bz, bsize, wcol, rcol in campus_blocks:
        r3d.add_box(
            center=(bx, by, bz),
            size=bsize,
            base_rgb=COLORS[wcol],
            top_rgb=COLORS["cream"],
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.4,
            alpha=0.88,
        )
        r3d.add_pitched_roof(
            center=(bx, by + bsize[1] * 0.5, bz),
            size=(bsize[0] + 10.0, 24.0, bsize[2] + 10.0),
            roof_rgb=COLORS[rcol],
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.4,
            alpha=0.88,
        )

    add_sculptural_agent_companion(r3d, (-150.0, -95.0, -10.0), "marketing", t, scale=0.72, alpha=0.95)
    add_sculptural_agent_companion(r3d, (0.0, -95.0, -30.0), "product", t, scale=0.72, alpha=0.95)
    add_sculptural_agent_companion(r3d, (150.0, -95.0, -10.0), "designer", t, scale=0.72, alpha=0.95)

    r3d.render()

    draw_pill_badge(
        ctx,
        x=96,
        y=42,
        text="RAZORGROWTH AI · UNIFIED GROWTH OPERATING SYSTEM",
        bg_key="cream",
        fg_key="espresso",
        dot_key="terracotta",
        alpha=ease_out_cubic(norm_time(lt, 0.05, 0.65)),
        font_size=13.0,
    )

    p_h1 = ease_out_cubic(norm_time(lt, 0.2, 1.1))
    p_h2 = ease_out_cubic(norm_time(lt, 0.9, 1.9))

    draw_masked_headline(
        ctx,
        x=96,
        y=114,
        text="Discover. Decide. Act.",
        size=58.0,
        color_key="espresso",
        progress=p_h1,
        align="left",
    )
    draw_masked_headline(
        ctx,
        x=760,
        y=114,
        text="One growth operating system.",
        size=54.0,
        color_key="terracotta",
        progress=p_h2,
        align="left",
    )

    er, eg, eb = COLORS["espresso"]
    tr, tg, tb = COLORS["taupe"]

    grid_x = [96.0, 686.0, 1276.0]
    grid_y = [164.0, 528.0]
    card_w = 548.0
    card_h = 318.0

    conn_p = ease_in_out_cubic(norm_time(lt, 1.1, 2.8))
    if conn_p > 0.01:
        ctx.save()
        cr, cg, cb = COLORS["terracotta"]
        ctx.set_source_rgba(cr, cg, cb, 0.85 * conn_p)
        ctx.set_line_width(2.8)
        ctx.new_path()
        ctx.move_to(grid_x[0] + card_w, grid_y[0] + card_h * 0.5)
        ctx.line_to(grid_x[1], grid_y[0] + card_h * 0.5)
        ctx.move_to(grid_x[1] + card_w, grid_y[0] + card_h * 0.5)
        ctx.line_to(grid_x[2], grid_y[0] + card_h * 0.5)
        ctx.move_to(grid_x[2] + card_w * 0.5, grid_y[0] + card_h)
        ctx.line_to(grid_x[0] + card_w * 0.5, grid_y[1])
        ctx.move_to(grid_x[0] + card_w, grid_y[1] + card_h * 0.5)
        ctx.line_to(grid_x[1], grid_y[1] + card_h * 0.5)
        ctx.move_to(grid_x[1] + card_w, grid_y[1] + card_h * 0.5)
        ctx.line_to(grid_x[2], grid_y[1] + card_h * 0.5)
        ctx.stroke()
        ctx.restore()

    # Window 1: Growth Radar
    w1_p = stagger(lt, 0.25, 0.8, 0, 0.16)
    wx, wy = grid_x[0], grid_y[0] + (1.0 - w1_p) * 28.0
    draw_browser_window(ctx, wx, wy, card_w, card_h, "01 · growth-radar.app", alpha=w1_p, header_h=34.0, tag_right="9 SIGNALS")
    if w1_p > 0.05:
        draw_pill_badge(ctx, wx + 20, wy + 50, "BUSINESS SIGNALS & RADAR", bg_key="parchment", fg_key="espresso", dot_key="terracotta", alpha=w1_p, font_size=11.5)
        draw_line_chart(ctx, wx + 20, wy + 96, card_w - 40, 145, [0.24, 0.35, 0.32, 0.58, 0.66, 0.85], progress=w1_p, stroke_key="terracotta", alpha=w1_p)
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(12.0)
        ctx.set_source_rgba(tr, tg, tb, w1_p)
        ctx.move_to(wx + 20, wy + 278)
        ctx.show_text("Retention · Product opportunity · Inventory risk · Failed payment")

    # Window 2: AI Team
    w2_p = stagger(lt, 0.25, 0.8, 1, 0.16)
    wx, wy = grid_x[1], grid_y[0] + (1.0 - w2_p) * 28.0
    draw_browser_window(ctx, wx, wy, card_w, card_h, "02 · ai-team — 15-specialists.app", alpha=w2_p, header_h=34.0, tag_right="3 GENERATIONS")
    if w2_p > 0.05:
        draw_pill_badge(ctx, wx + 20, wy + 50, "SPECIALIST INVESTIGATION", bg_key="parchment", fg_key="espresso", dot_key="sage", alpha=w2_p, font_size=11.5)
        roles = [
            ("Marketing Agent", "Segments, win-back & campaign drafts", "terracotta"),
            ("Product Agent", "Affinity, bundling & inventory risk", "sage"),
            ("Designer Agent", "Creative briefs, assets & UX review", "ochre"),
        ]
        for idx, (rn, rd, rc) in enumerate(roles):
            ry = wy + 94 + idx * 66
            draw_card(ctx, wx + 20, ry, card_w - 40, 54, bg_key="parchment", accent_key=rc, shadow_offset=2.0, alpha=w2_p)
            ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(15.0)
            ctx.set_source_rgba(er, eg, eb, w2_p)
            ctx.move_to(wx + 36, ry + 22)
            ctx.show_text(rn)
            ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
            ctx.set_font_size(11.5)
            ctx.set_source_rgba(tr, tg, tb, w2_p)
            ctx.move_to(wx + 36, ry + 41)
            ctx.show_text(rd)

    # Window 3: Agent Debates
    w3_p = stagger(lt, 0.25, 0.8, 2, 0.16)
    wx, wy = grid_x[2], grid_y[0] + (1.0 - w3_p) * 28.0
    draw_browser_window(ctx, wx, wy, card_w, card_h, "03 · agent-debates.app", alpha=w3_p, header_h=34.0, tag_right="SYNTHESIS")
    if w3_p > 0.05:
        draw_pill_badge(ctx, wx + 20, wy + 50, "STRUCTURED DEBATE WORKFLOW", bg_key="parchment", fg_key="espresso", dot_key="ochre", alpha=w3_p, font_size=11.5)
        draw_card(ctx, wx + 20, wy + 94, card_w - 40, 88, bg_key="parchment", accent_key="sage", shadow_offset=2.0, alpha=w3_p)
        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(15.5)
        ctx.set_source_rgba(er, eg, eb, w3_p)
        ctx.move_to(wx + 36, wy + 126)
        ctx.show_text("Supporting Evidence vs. Stock & Margin Guardrails")
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(12.0)
        ctx.set_source_rgba(tr, tg, tb, w3_p)
        ctx.move_to(wx + 36, wy + 156)
        ctx.show_text("Manager coordination resolves uncertainty before action.")

        draw_card(ctx, wx + 20, wy + 198, card_w - 40, 92, bg_key="cream_soft", accent_key="terracotta", shadow_offset=3.0, alpha=w3_p)
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(12.5)
        ctx.set_source_rgba(er, eg, eb, w3_p)
        ctx.move_to(wx + 36, wy + 232)
        ctx.show_text("SYNTHESIZED PLAN: STOCK-GUARDED COHORT BUNDLE")
        ctx.move_to(wx + 36, wy + 260)
        ctx.set_source_rgba(tr, tg, tb, w3_p)
        ctx.show_text("Forwarded to Human Approval Gate with full audit trail.")

    # Window 4: Actions & Human Approval
    w4_p = stagger(lt, 0.25, 0.8, 3, 0.16)
    wx, wy = grid_x[0], grid_y[1] + (1.0 - w4_p) * 28.0
    draw_browser_window(ctx, wx, wy, card_w, card_h, "04 · actions-approval.app", alpha=w4_p, header_h=34.0, tag_right="HUMAN GATE")
    if w4_p > 0.05:
        draw_pill_badge(ctx, wx + 20, wy + 50, "APPROVED BY HUMAN OPERATOR", bg_key="sage_light", fg_key="espresso", dot_key="sage", alpha=w4_p, font_size=11.5)
        draw_card(ctx, wx + 20, wy + 94, card_w - 40, 128, bg_key="parchment", accent_key="terracotta", shadow_offset=2.0, alpha=w4_p)
        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(17.0)
        ctx.set_source_rgba(er, eg, eb, w4_p)
        ctx.move_to(wx + 36, wy + 130)
        ctx.show_text("Proposed Action: Cohort Win-Back Workflow")
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(12.0)
        ctx.set_source_rgba(tr, tg, tb, w4_p)
        ctx.move_to(wx + 36, wy + 162)
        ctx.show_text("Expected impact — estimate · Evidence attached")
        ctx.move_to(wx + 36, wy + 190)
        ctx.show_text("Consequential external execution requires human sign-off.")
        draw_button(ctx, wx + 20, wy + 242, 210, 44, "STATUS: APPROVED", variant="approved", alpha=w4_p, font_size=14.0)

    # Window 5: Business Intelligence & Measurement
    w5_p = stagger(lt, 0.25, 0.8, 4, 0.16)
    wx, wy = grid_x[1], grid_y[1] + (1.0 - w5_p) * 28.0
    draw_browser_window(ctx, wx, wy, card_w, card_h, "05 · bi-intelligence.app", alpha=w5_p, header_h=34.0, tag_right="MEASUREMENT")
    if w5_p > 0.05:
        draw_pill_badge(ctx, wx + 20, wy + 50, "CUSTOMER, PRODUCT & CAMPAIGN BI", bg_key="parchment", fg_key="espresso", dot_key="sage", alpha=w5_p, font_size=11.5)
        bi_rows = [
            ("Customer & Cohort Analytics", "Unified retention & segment telemetry"),
            ("Product & Bundle Intelligence", "SKU velocity, affinity & stock tracking"),
            ("Outcome Measurement Capability", "Active tracking · Learning loop on roadmap"),
        ]
        for idx, (bt, bs) in enumerate(bi_rows):
            ry = wy + 94 + idx * 66
            draw_card(ctx, wx + 20, ry, card_w - 40, 54, bg_key="parchment", accent_key="sage" if idx < 2 else "ochre", shadow_offset=2.0, alpha=w5_p)
            ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(15.0)
            ctx.set_source_rgba(er, eg, eb, w5_p)
            ctx.move_to(wx + 36, ry + 22)
            ctx.show_text(bt)
            ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
            ctx.set_font_size(11.5)
            ctx.set_source_rgba(tr, tg, tb, w5_p)
            ctx.move_to(wx + 36, ry + 41)
            ctx.show_text(bs)

    # Window 6: Checkout Destination
    w6_p = stagger(lt, 0.25, 0.8, 5, 0.16)
    wx, wy = grid_x[2], grid_y[1] + (1.0 - w6_p) * 28.0
    draw_browser_window(ctx, wx, wy, card_w, card_h, "06 · checkout.app", alpha=w6_p, header_h=34.0, tag_right="ECOSYSTEM")
    if w6_p > 0.05:
        draw_pill_badge(ctx, wx + 20, wy + 50, "CHECKOUT DESTINATION SURFACE", bg_key="parchment", fg_key="espresso", dot_key="terracotta", alpha=w6_p, font_size=11.5)
        draw_card(ctx, wx + 20, wy + 94, card_w - 40, 125, bg_key="parchment", accent_key="terracotta", shadow_offset=2.0, alpha=w6_p)
        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(16.5)
        ctx.set_source_rgba(er, eg, eb, w6_p)
        ctx.move_to(wx + 36, wy + 126)
        ctx.show_text("Curated Bundle Checkout Flow")
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(12.0)
        ctx.set_source_rgba(tr, tg, tb, w6_p)
        ctx.move_to(wx + 36, wy + 156)
        ctx.show_text("CART SUMMARY  ->  PAYMENT METHOD  ->  ORDER REVIEW")
        ctx.move_to(wx + 36, wy + 186)
        ctx.show_text("Illustrated payment flow destination in RazorGrowth OS")
        draw_button(ctx, wx + 20, wy + 238, 240, 44, "CHECKOUT SURFACE", variant="secondary", alpha=w6_p, font_size=13.5)

    prog_p = ease_out_cubic(norm_time(lt, 1.4, 2.5))
    if prog_p > 0.01:
        draw_card(ctx, 96, 878, 1728, 56, bg_key="cream", accent_key="terracotta", shadow_offset=4.0, alpha=prog_p)
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(13.0)
        ctx.set_source_rgba(er, eg, eb, prog_p)
        ctx.move_to(124, 912)
        ctx.show_text(
            "BUSINESS SIGNALS  ->  AI INVESTIGATION  ->  SPECIALIST REASONING  ->  OPPORTUNITY DISCOVERY  ->  ACTION PLANNING  ->  HUMAN APPROVAL  ->  MEASUREMENT"
        )
