"""
SCENE 6 — HUMAN APPROVAL (00:38–00:47)
- Emotional and trust-building centerpiece.
- Recommendation card enters the center of the screen including:
  * "Proposed action"
  * "Evidence"
  * "Expected impact — estimate"
  * "Human review required"
  * Two controls: "Reject" and "Approve"
- A human cursor moves into the frame and selects "Approve" at lt = 4.2s (global t = 42.2s).
- Button changes state with a restrained terracotta confirmation mark and muted sage indicator.
- A thin connection line travels toward the execution workspace after approval.
- On-screen text:
  "AI moves work forward."
  Then: "You stay in control."
"""
import math
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_SANS, FONT_MONO
from src.animations.easing import norm_time, ease_out_cubic, ease_out_back, ease_in_out_cubic
from src.components.ui_kit import (
    draw_browser_window,
    draw_card,
    draw_button,
    draw_pill_badge,
    draw_masked_headline,
    draw_human_cursor,
    rounded_rect_path,
)


def render_scene6(ctx: cairo.Context, t: float):
    lt = t - 38.0

    pr, pg, pb = COLORS["parchment"]
    ctx.set_source_rgb(pr, pg, pb)
    ctx.paint()

    er, eg, eb = COLORS["espresso"]
    tr, tg, tb = COLORS["taupe"]

    draw_pill_badge(
        ctx,
        x=120,
        y=46,
        text="HUMAN APPROVAL GATE · CONSEQUENTIAL ACTIONS STAY UNDER HUMAN CONTROL",
        bg_key="cream",
        fg_key="espresso",
        dot_key="terracotta",
        alpha=ease_out_cubic(norm_time(lt, 0.05, 0.7)),
        font_size=13.0,
    )

    p_h1 = ease_out_cubic(norm_time(lt, 0.25, 1.15))
    p_h2 = ease_out_cubic(norm_time(lt, 2.20, 3.20))

    draw_masked_headline(
        ctx,
        x=120,
        y=124,
        text="AI moves work forward.",
        size=56.0,
        color_key="espresso",
        progress=p_h1,
        align="left",
    )
    draw_masked_headline(
        ctx,
        x=815,
        y=124,
        text="You stay in control.",
        size=56.0,
        color_key="terracotta",
        progress=p_h2,
        align="left",
    )

    card_p = ease_out_back(norm_time(lt, 0.15, 1.05), overshoot=1.05)
    card_alpha = ease_out_cubic(norm_time(lt, 0.1, 0.65))
    cw, ch = 1140.0, 650.0
    cx = 120.0
    cy = 172.0 + (1.0 - card_p) * 58.0

    is_approved = lt >= 4.35
    approval_p = ease_out_cubic(norm_time(lt, 4.35, 5.10))

    draw_browser_window(
        ctx,
        x=cx,
        y=cy,
        w=cw,
        h=ch,
        title="action-approval — human-review.app",
        alpha=card_alpha,
        shadow_offset=12.0,
        corner_r=7.0,
        header_h=40.0,
        bg_key="cream",
        tag_right="APPROVED · QUEUED FOR EXECUTION" if is_approved else "AWAITING HUMAN OPERATOR",
    )

    if card_alpha <= 0.05:
        return

    draw_pill_badge(
        ctx,
        x=cx + 36,
        y=cy + 62,
        text="Human review required",
        bg_key="parchment",
        fg_key="espresso",
        dot_key="terracotta" if not is_approved else "sage",
        alpha=card_alpha,
        font_size=14.0,
    )

    if approval_p > 0.01:
        draw_pill_badge(
            ctx,
            x=cx + 310,
            y=cy + 62,
            text="APPROVED BY HUMAN OPERATOR · AUDIT LOG RECORDED",
            bg_key="sage_light",
            fg_key="espresso",
            dot_key="sage",
            alpha=approval_p,
            font_size=13.5,
        )

    # Section 1: "Proposed action"
    s1_y = cy + 114
    draw_card(ctx, cx + 36, s1_y, cw - 72, 126, bg_key="parchment", accent_key="terracotta", shadow_offset=4.0, alpha=card_alpha)
    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(13.5)
    ctx.set_source_rgba(tr, tg, tb, card_alpha)
    ctx.move_to(cx + 58, s1_y + 30)
    ctx.show_text("Proposed action")

    ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(23.0)
    ctx.set_source_rgba(er, eg, eb, card_alpha)
    ctx.move_to(cx + 58, s1_y + 66)
    ctx.show_text("Launch 45-Day Repeat Cohort Win-Back & Stock-Guarded Bundle")

    ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
    ctx.set_font_size(17.0)
    ctx.set_source_rgba(er, eg, eb, 0.85 * card_alpha)
    ctx.move_to(cx + 58, s1_y + 98)
    ctx.show_text("Prepared by Marketing, Product, and Designer Agents · Low-stock Variant-B excluded automatically.")

    # Section 2: "Evidence" & Section 3: "Expected impact — estimate"
    s2_y = s1_y + 148
    half_w = (cw - 92) * 0.5

    draw_card(ctx, cx + 36, s2_y, half_w, 195, bg_key="parchment", accent_key="sage", shadow_offset=4.0, alpha=card_alpha)
    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(13.5)
    ctx.set_source_rgba(tr, tg, tb, card_alpha)
    ctx.move_to(cx + 56, s2_y + 30)
    ctx.show_text("Evidence")

    ev_lines = [
        "• Retention Radar signal verified on 45-day buyer cohort.",
        "• Core SKU-A + Refill Pack affinity validated by Product Agent.",
        "• Inventory safeguard confirms 60+ day stock buffer on SKU-A.",
        "• Creative brief & email draft reviewed by Designer Agent.",
    ]
    ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
    ctx.set_font_size(15.5)
    ctx.set_source_rgba(er, eg, eb, card_alpha)
    for idx, line in enumerate(ev_lines):
        ctx.move_to(cx + 56, s2_y + 66 + idx * 32)
        ctx.show_text(line)

    rx = cx + 56 + half_w
    draw_card(ctx, rx, s2_y, half_w, 195, bg_key="parchment", accent_key="ochre", shadow_offset=4.0, alpha=card_alpha)
    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(13.5)
    ctx.set_source_rgba(tr, tg, tb, card_alpha)
    ctx.move_to(rx + 20, s2_y + 30)
    ctx.show_text("Expected impact — estimate")

    imp_lines = [
        "• Illustrative planning estimate (non-guaranteed projection).",
        "• Model scope: Targeted repeat-buyer segment recovery.",
        "• Margin protection: Zero site-wide discount dilution.",
        "• Outcome tracking: Scheduled for post-action BI measurement.",
    ]
    ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
    ctx.set_font_size(15.5)
    ctx.set_source_rgba(er, eg, eb, card_alpha)
    for idx, line in enumerate(imp_lines):
        ctx.move_to(rx + 20, s2_y + 66 + idx * 32)
        ctx.show_text(line)

    # Bottom Action Bar: "Reject" and "Approve" controls + Restrained Terracotta Confirmation Mark
    btn_y = cy + 542
    reject_x = cx + 36
    approve_x = cx + 236
    btn_w = 180.0
    btn_h = 56.0

    press_amt = 0.0
    if 4.05 <= lt <= 4.50:
        press_amt = math.sin(norm_time(lt, 4.05, 4.50) * math.pi)

    draw_button(
        ctx,
        x=reject_x,
        y=btn_y,
        w=172.0,
        h=btn_h,
        label="Reject",
        variant="secondary",
        pressed=0.0,
        alpha=card_alpha,
        font_size=18.0,
    )

    draw_button(
        ctx,
        x=approve_x,
        y=btn_y,
        w=btn_w,
        h=btn_h,
        label="Approved" if is_approved else "Approve",
        variant="primary",
        pressed=press_amt,
        alpha=card_alpha,
        font_size=18.0,
    )

    if approval_p > 0.01:
        mark_cx = approve_x + btn_w + 46
        mark_cy = btn_y + btn_h * 0.5

        ctx.save()
        cr, cg, cb = COLORS["terracotta"]
        ctx.new_path()
        ctx.arc(mark_cx, mark_cy, 22.0 * approval_p, 0, math.pi * 2)
        ctx.set_source_rgba(cr, cg, cb, approval_p)
        ctx.fill_preserve()
        ctx.set_source_rgba(er, eg, eb, approval_p)
        ctx.set_line_width(2.0)
        ctx.stroke()

        ctx.new_path()
        ctx.set_source_rgba(COLORS["cream"][0], COLORS["cream"][1], COLORS["cream"][2], approval_p)
        ctx.set_line_width(3.2)
        ctx.move_to(mark_cx - 9, mark_cy + 1)
        ctx.line_to(mark_cx - 2, mark_cy + 8)
        ctx.line_to(mark_cx + 10, mark_cy - 7)
        ctx.stroke()

        sr, sg, sb = COLORS["sage"]
        rounded_rect_path(ctx, mark_cx + 38, btn_y + 8, 520 * approval_p, 40, 4.0)
        ctx.set_source_rgba(sr, sg, sb, 0.18 * approval_p)
        ctx.fill_preserve()
        ctx.set_source_rgba(sr, sg, sb, approval_p)
        ctx.set_line_width(1.8)
        ctx.stroke()

        if approval_p > 0.45:
            ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(13.5)
            ctx.set_source_rgba(er, eg, eb, approval_p)
            ctx.move_to(mark_cx + 56, btn_y + 33)
            ctx.show_text("APPROVAL CONFIRMED · DISPATCHING TO EXECUTION WORKSPACE")
        ctx.restore()

    exec_x = 1340.0
    exec_y = 260.0
    exec_w = 460.0
    exec_h = 480.0
    exec_p = ease_out_cubic(norm_time(lt, 1.2, 2.2))

    draw_browser_window(
        ctx,
        x=exec_x,
        y=exec_y,
        w=exec_w,
        h=exec_h,
        title="execution-workspace.app",
        alpha=exec_p,
        shadow_offset=9.0,
        header_h=36.0,
        tag_right="ACTIVE" if is_approved else "LOCKED UNTIL APPROVAL",
    )

    if exec_p > 0.05:
        draw_pill_badge(
            ctx,
            exec_x + 22,
            exec_y + 56,
            "EXECUTION GATE: UNLOCKED BY HUMAN" if is_approved else "EXECUTION GATE: STANDBY",
            bg_key="sage_light" if is_approved else "parchment",
            fg_key="espresso",
            dot_key="sage" if is_approved else "taupe",
            alpha=exec_p,
            font_size=12.0,
        )

        steps = [
            ("1. Segment Export", "45-day repeat buyer cohort staged"),
            ("2. Bundle Offer Assembly", "SKU-A + Refill Pack · Variant-B excluded"),
            ("3. Campaign Dispatch", "Authorized by human approval token"),
            ("4. Outcome Measurement", "BI telemetry hook armed for tracking"),
        ]
        for idx, (st_title, st_sub) in enumerate(steps):
            sy_row = exec_y + 106 + idx * 86
            active_step = is_approved and (lt >= 5.0 + idx * 0.45)
            draw_card(
                ctx,
                exec_x + 22,
                sy_row,
                exec_w - 44,
                72,
                bg_key="cream_soft" if active_step else "parchment",
                accent_key="sage" if active_step else "taupe",
                shadow_offset=3.0 if active_step else 1.0,
                alpha=exec_p,
            )
            ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(16.0)
            ctx.set_source_rgba(er, eg, eb, exec_p)
            ctx.move_to(exec_x + 40, sy_row + 28)
            ctx.show_text(st_title)

            ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
            ctx.set_font_size(12.0)
            ctx.set_source_rgba(tr, tg, tb, exec_p)
            ctx.move_to(exec_x + 40, sy_row + 52)
            ctx.show_text(st_sub)

    line_p = ease_in_out_cubic(norm_time(lt, 4.55, 5.65))
    if line_p > 0.01:
        ctx.save()
        cr, cg, cb = COLORS["terracotta"]
        sx_line = cx + cw
        sy_line = btn_y + btn_h * 0.5
        ex_line = exec_x
        ey_line = exec_y + 240

        cur_x = sx_line + (ex_line - sx_line) * line_p
        cur_y = sy_line + (ey_line - sy_line) * line_p
        ctx.set_source_rgba(cr, cg, cb, 0.95)
        ctx.set_line_width(3.4)
        ctx.new_path()
        ctx.move_to(sx_line, sy_line)
        ctx.line_to(cur_x, cur_y)
        ctx.stroke()

        ctx.new_path()
        ctx.arc(cur_x, cur_y, 6.0, 0, math.pi * 2)
        ctx.fill()
        ctx.restore()

    cur_enter = ease_in_out_cubic(norm_time(lt, 1.85, 3.85))
    if lt > 1.75:
        start_cx, start_cy = 960.0, 880.0
        target_cx, target_cy = approve_x + btn_w * 0.54, btn_y + btn_h * 0.56
        cur_x = start_cx + (target_cx - start_cx) * cur_enter
        cur_y = start_cy + (target_cy - start_cy) * cur_enter
        click_pulse = norm_time(lt, 4.15, 4.85) if 4.15 <= lt <= 4.85 else 0.0
        draw_human_cursor(ctx, cur_x, cur_y, click_pulse=click_pulse, alpha=1.0)
