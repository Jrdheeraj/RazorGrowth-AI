"""
SCENE 1 — THE BUSINESS WORLD (00:00–00:06)
- Wide establishing shot of warm peach sky and illustrated miniature business neighborhood.
- Clouds drift gently; buildings reveal parallax and extrude into 2.5D/3D depth as camera pushes forward.
- Small business signals appear: product card, customer signal, inventory indicator, and growth chart.
- Editorial headline: "Every business has room to grow."
- Motivated transition: a terracotta line emerges from the environment and leads toward the rising product window.
"""
import math
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_MONO
from src.animations.easing import norm_time, ease_out_cubic, ease_in_out_cubic, stagger
from src.components.environment import draw_business_neighborhood, draw_floating_signal_cue
from src.components.ui_kit import draw_masked_headline, draw_pill_badge


def render_scene1(ctx: cairo.Context, t: float):
    # t in [0.0, 6.0]
    u = norm_time(t, 0.0, 6.0)
    cam_push = ease_in_out_cubic(u)
    extrude_3d = ease_in_out_cubic(norm_time(t, 1.2, 5.2))
    pan_x = (u - 0.5) * 65.0

    # 1. Illustrated miniature business neighborhood with 2.5D -> 3D extrusion
    draw_business_neighborhood(
        ctx,
        t=t,
        cam_push=cam_push,
        extrude_3d=extrude_3d,
        pan_x=pan_x,
        horizon_y=740.0,
        alpha=1.0,
    )

    # 2. Top-left editorial header tag
    tag_p = ease_out_cubic(norm_time(t, 0.3, 1.1))
    draw_pill_badge(
        ctx,
        x=110,
        y=68,
        text="RAZORGROWTH AI · BUSINESS SIGNALS",
        bg_key="cream",
        fg_key="espresso",
        dot_key="terracotta",
        alpha=tag_p,
        font_size=13.5,
    )

    # 3. Large espresso editorial headline: "Every business has room to grow."
    hl_p = ease_out_cubic(norm_time(t, 0.55, 1.75))
    draw_masked_headline(
        ctx,
        x=WIDTH * 0.5,
        y=215,
        text="Every business has room to grow.",
        size=74.0,
        color_key="espresso",
        progress=hl_p,
        align="center",
    )

    # Subtle editorial subtitle
    sub_p = ease_out_cubic(norm_time(t, 1.1, 2.2))
    if sub_p > 0.01:
        ctx.save()
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(16.0)
        msg = "SIGNALS EMERGE ACROSS CUSTOMERS · PRODUCTS · INVENTORY · CAMPAIGNS"
        ext = ctx.text_extents(msg)
        r, g, b = COLORS["taupe"]
        ctx.set_source_rgba(r, g, b, sub_p)
        ctx.move_to((WIDTH - ext.width) * 0.5, 265)
        ctx.show_text(msg)
        ctx.restore()

    # 4. Four business signals emerging from storefronts (staggered)
    signals = [
        (130, 445, 245, 620, "Product Card", "Affinity bundle signal", "terracotta", "product"),
        (545, 410, 650, 610, "Customer Signal", "Repeat cohort window", "sage", "customer"),
        (1045, 420, 1185, 615, "Inventory Indicator", "Stock velocity shift", "ochre", "inventory"),
        (1485, 440, 1605, 625, "Growth Chart", "Demand momentum cue", "terracotta", "chart"),
    ]
    for idx, (sx, sy, ax, ay, cat, title, bkey, kind) in enumerate(signals):
        sp = stagger(t, base_start=1.35, duration=0.95, index=idx, step=0.32)
        draw_floating_signal_cue(
            ctx,
            x=sx,
            y=sy,
            anchor_x=ax,
            anchor_y=ay,
            category=cat,
            title=title,
            badge_key=bkey,
            progress=sp,
            kind=kind,
        )

    # 5. Motivated Transition (04.4s -> 06.0s):
    # A terracotta connection line emerges from the business signals and rises toward the center product window
    tr_p = ease_in_out_cubic(norm_time(t, 4.3, 5.95))
    if tr_p > 0.01:
        ctx.save()
        cr, cg, cb = COLORS["terracotta"]
        ctx.set_source_rgba(cr, cg, cb, 0.92)
        ctx.set_line_width(3.0)
        for sx, sy, _, _, _, _, _, _ in signals:
            start_pt = (sx + 114, sy)
            mid_pt = (WIDTH * 0.5, 340)
            cur_x = start_pt[0] + (mid_pt[0] - start_pt[0]) * tr_p
            cur_y = start_pt[1] + (mid_pt[1] - start_pt[1]) * tr_p
            ctx.move_to(start_pt[0], start_pt[1])
            ctx.line_to(cur_x, cur_y)
            ctx.stroke()

        # Central rising node pulse that seeds the welcome.app window in Scene 2
        ctx.arc(WIDTH * 0.5, 340, 8.0 * tr_p, 0, math.pi * 2)
        ctx.fill()
        ctx.restore()
