"""
RazorGrowth AI — Master Timeline & Motivated Scene Composer
Coordinates all 8 scenes across the 62-second launch film, preview reel, and 15-second teaser.
"""
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_MONO
from src.animations.easing import norm_time, ease_in_out_cubic
from src.scenes.scene1_business_world import render_scene1
from src.scenes.scene2_product_reveal import render_scene2
from src.scenes.scene3_ai_team import render_scene3
from src.scenes.scene4_growth_radar import render_scene4
from src.scenes.scene5_debate_synthesize import render_scene5
from src.scenes.scene6_human_approval import render_scene6
from src.scenes.scene7_growth_os import render_scene7
from src.scenes.scene8_brand_finale import render_scene8


def _render_single_scene(ctx: cairo.Context, scene_idx: int, t: float):
    if scene_idx == 1:
        render_scene1(ctx, t)
    elif scene_idx == 2:
        render_scene2(ctx, t)
    elif scene_idx == 3:
        render_scene3(ctx, t)
    elif scene_idx == 4:
        render_scene4(ctx, t)
    elif scene_idx == 5:
        render_scene5(ctx, t)
    elif scene_idx == 6:
        render_scene6(ctx, t)
    elif scene_idx == 7:
        render_scene7(ctx, t)
    else:
        render_scene8(ctx, t)


def draw_editorial_frame_border_and_progress(ctx: cairo.Context, t: float, total_dur: float = 62.0):
    """Draws a subtle editorial perimeter hairline and bottom timeline progress indicator."""
    ctx.save()
    er, eg, eb = COLORS["espresso"]
    ctx.set_source_rgba(er, eg, eb, 0.14)
    ctx.set_line_width(1.5)
    ctx.rectangle(18, 18, WIDTH - 36, HEIGHT - 36)
    ctx.stroke()

    # Subtle bottom terracotta progress hairline
    prog = max(0.0, min(1.0, t / total_dur))
    cr, cg, cb = COLORS["terracotta"]
    ctx.set_source_rgba(cr, cg, cb, 0.65)
    ctx.rectangle(18, HEIGHT - 21, (WIDTH - 36) * prog, 3.0)
    ctx.fill()
    ctx.restore()


def render_frame_at_time(
    ctx: cairo.Context,
    t: float,
    scratch_surf: cairo.ImageSurface = None,
    scratch_ctx: cairo.Context = None,
):
    """Renders the full 62.0s launch film frame at timestamp t with smooth 0.35s cross-scene transitions."""
    boundaries = [
        (6.0, 1, 2),
        (13.0, 2, 3),
        (22.0, 3, 4),
        (30.0, 4, 5),
        (38.0, 5, 6),
        (47.0, 6, 7),
        (55.0, 7, 8),
    ]
    half_tr = 0.22

    for b_time, s_prev, s_next in boundaries:
        if (b_time - half_tr) <= t < (b_time + half_tr) and scratch_surf is not None and scratch_ctx is not None:
            u = ease_in_out_cubic(norm_time(t, b_time - half_tr, b_time + half_tr))
            _render_single_scene(ctx, s_prev, min(t, b_time - 0.001))
            _render_single_scene(scratch_ctx, s_next, max(t, b_time))
            ctx.save()
            ctx.set_source_surface(scratch_surf, 0, 0)
            ctx.paint_with_alpha(u)
            ctx.restore()
            draw_editorial_frame_border_and_progress(ctx, t, 62.0)
            return

    if t < 6.0:
        _render_single_scene(ctx, 1, t)
    elif t < 13.0:
        _render_single_scene(ctx, 2, t)
    elif t < 22.0:
        _render_single_scene(ctx, 3, t)
    elif t < 30.0:
        _render_single_scene(ctx, 4, t)
    elif t < 38.0:
        _render_single_scene(ctx, 5, t)
    elif t < 47.0:
        _render_single_scene(ctx, 6, t)
    elif t < 55.0:
        _render_single_scene(ctx, 7, t)
    else:
        _render_single_scene(ctx, 8, t)

    draw_editorial_frame_border_and_progress(ctx, t, 62.0)


def render_teaser_frame_at_time(
    ctx: cairo.Context,
    t: float,
    scratch_surf: cairo.ImageSurface = None,
    scratch_ctx: cairo.Context = None,
):
    """
    Renders the 15-second teaser derived directly from the film scenes:
    - 00.0–03.0s: Scene 1 (Business World & 3D transformation)
    - 03.0–06.5s: Scene 3 (Meet the AI Team 3D companions)
    - 06.5–10.5s: Scene 6 (Human Approval click sequence)
    - 10.5–15.0s: Scene 8 (Brand Finale — "Run your growth engine with AI employees.")
    """
    if t < 3.0:
        mapped_t = 1.0 + (t / 3.0) * 4.5
        render_scene1(ctx, mapped_t)
    elif t < 6.5:
        mapped_t = 13.5 + ((t - 3.0) / 3.5) * 6.0
        render_scene3(ctx, mapped_t)
    elif t < 10.5:
        mapped_t = 39.8 + ((t - 6.5) / 4.0) * 6.2
        render_scene6(ctx, mapped_t)
    else:
        mapped_t = 55.2 + ((t - 10.5) / 4.5) * 6.2
        render_scene8(ctx, mapped_t)

    draw_editorial_frame_border_and_progress(ctx, t, 15.0)
