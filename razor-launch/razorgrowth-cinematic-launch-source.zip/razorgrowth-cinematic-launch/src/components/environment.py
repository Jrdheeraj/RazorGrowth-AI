"""
RazorGrowth AI — Custom Illustrated Miniature Business Neighborhood (2.5D & 3D)
Implements the background world & signature 3D transformation sequence:
- Warm peach sky & drifting soft cream clouds
- Layered low-rise storefronts and office buildings
- Muted sage and dusty green ground planes
- Terracotta and sand-colored roofs
- Thin dark (#26150F) architectural outlines
- Small stylized trees, sidewalks, windows catching warm light, and street details
- Signature 3D extrusion where selected storefronts gain dimensional depth
"""
import math
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT, FONT_MONO, FONT_SANS
from src.components.ui_kit import rounded_rect_path, draw_card


def draw_sky_and_clouds(ctx: cairo.Context, t: float, pan_x: float = 0.0, horizon_y: float = 720.0):
    """Draws warm peach sky gradient and drifting soft cream editorial clouds."""
    ctx.save()
    grad = cairo.LinearGradient(0, 0, 0, horizon_y)
    st = COLORS["sky_top"]
    sb = COLORS["sky_bottom"]
    grad.add_color_stop_rgb(0.0, st[0], st[1], st[2])
    grad.add_color_stop_rgb(0.68, sb[0], sb[1], sb[2])
    grad.add_color_stop_rgb(1.0, COLORS["parchment"][0], COLORS["parchment"][1], COLORS["parchment"][2])
    ctx.rectangle(0, 0, WIDTH, HEIGHT)
    ctx.set_source(grad)
    ctx.fill()

    # Subtle paper grain horizontal hairlines for warm tactile editorial feel
    er, eg, eb = COLORS["taupe"]
    ctx.set_source_rgba(er, eg, eb, 0.04)
    ctx.set_line_width(1.0)
    ctx.new_path()
    for y in range(40, int(horizon_y), 36):
        ctx.move_to(0, y)
        ctx.line_to(WIDTH, y)
    ctx.stroke()

    # Soft cream clouds with clean unified silhouette (no internal overlapping rings)
    cloud_specs = [
        (240, 130, 185, 42, 12.0),
        (690, 92, 230, 48, 9.5),
        (1210, 135, 200, 44, 14.0),
        (1620, 102, 175, 38, 11.0),
    ]
    cr, cg, cb = COLORS["cream"]
    dr, dg, db = COLORS["espresso"]
    sr, sg, sb = COLORS["sand"]

    for idx, (bx, by, cw, ch, speed) in enumerate(cloud_specs):
        cx = (bx + t * speed - pan_x * (0.12 + 0.03 * (idx % 3))) % (WIDTH + 320) - 160
        cy = by
        # Sand offset shadow
        rounded_rect_path(ctx, cx + 4, cy + ch * 0.25 + 4, cw, ch * 0.75, ch * 0.36)
        ctx.set_source_rgba(sr, sg, sb, 0.42)
        ctx.fill()

        # Outer stroke layer behind fill for unified silhouette
        ctx.set_source_rgba(dr, dg, db, 0.48)
        for lx, ly, lr in [
            (cx + cw * 0.28, cy + ch * 0.45, ch * 0.46 + 1.5),
            (cx + cw * 0.54, cy + ch * 0.34, ch * 0.56 + 1.5),
            (cx + cw * 0.76, cy + ch * 0.48, ch * 0.40 + 1.5),
        ]:
            ctx.new_path()
            ctx.arc(lx, ly, lr, 0, math.pi * 2)
            ctx.fill()
        rounded_rect_path(ctx, cx - 1.5, cy + ch * 0.24 - 1.5, cw + 3.0, ch * 0.76 + 3.0, ch * 0.38)
        ctx.fill()

        # Pure warm cream interior fill
        ctx.set_source_rgba(cr, cg, cb, 0.96)
        for lx, ly, lr in [
            (cx + cw * 0.28, cy + ch * 0.45, ch * 0.46),
            (cx + cw * 0.54, cy + ch * 0.34, ch * 0.56),
            (cx + cw * 0.76, cy + ch * 0.48, ch * 0.40),
        ]:
            ctx.new_path()
            ctx.arc(lx, ly, lr, 0, math.pi * 2)
            ctx.fill()
        rounded_rect_path(ctx, cx, cy + ch * 0.24, cw, ch * 0.76, ch * 0.38)
        ctx.fill()

    ctx.restore()


def draw_stylized_tree(ctx: cairo.Context, x: float, y: float, scale: float = 1.0, alpha: float = 1.0):
    """Draws an editorial miniature tree with espresso trunk and layered sage/dusty-green foliage."""
    if alpha <= 0.01:
        return
    ctx.save()
    ctx.translate(x, y)
    ctx.scale(scale, scale)

    er, eg, eb = COLORS["espresso"]
    # Ground shadow ellipse
    ctx.save()
    ctx.scale(1.0, 0.32)
    ctx.new_path()
    ctx.arc(4, 0, 22, 0, math.pi * 2)
    ctx.set_source_rgba(er, eg, eb, 0.16 * alpha)
    ctx.fill()
    ctx.restore()

    # Trunk
    ctx.new_path()
    ctx.rectangle(-3.5, -28, 7, 28)
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.fill()

    # Canopy shadow lobe
    dr, dg, db = COLORS["dusty_green"]
    ctx.new_path()
    ctx.arc(4, -46, 22, 0, math.pi * 2)
    ctx.set_source_rgba(dr, dg, db, alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.6)
    ctx.stroke()

    # Main sage canopy
    sr, sg, sb = COLORS["sage"]
    ctx.new_path()
    ctx.arc(-2, -52, 20, 0, math.pi * 2)
    ctx.set_source_rgba(sr, sg, sb, alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.6)
    ctx.stroke()

    # Top highlight crown
    ctx.new_path()
    ctx.arc(-5, -66, 13, 0, math.pi * 2)
    ctx.set_source_rgba(sr + 0.06, sg + 0.06, sb + 0.04, alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.5)
    ctx.stroke()

    ctx.restore()


def draw_25d_storefront(
    ctx: cairo.Context,
    x: float,
    y_base: float,
    w: float,
    h: float,
    depth_3d: float,
    wall_key: str,
    roof_key: str,
    sign_label: str = None,
    has_awning: bool = True,
    warm_glow: float = 0.5,
    alpha: float = 1.0,
):
    """
    Draws a miniature storefront/office building that smoothly extrudes from 2D into 2.5D/3D depth.
    """
    if alpha <= 0.01:
        return
    ctx.save()
    er, eg, eb = COLORS["espresso"]
    dx = depth_3d * 34.0
    dy = -depth_3d * 18.0
    top_y = y_base - h

    # 1. Ground cast shadow
    ctx.new_path()
    ctx.move_to(x + 8, y_base + 4)
    ctx.line_to(x + w + dx + 18, y_base + 4)
    ctx.line_to(x + w + dx + 6, y_base + 14)
    ctx.line_to(x - 4, y_base + 14)
    ctx.close_path()
    ctx.set_source_rgba(er, eg, eb, 0.14 * alpha)
    ctx.fill()

    # 2. 3D Right side wall (visible as depth_3d > 0)
    if depth_3d > 0.02:
        wr, wg, wb = COLORS[wall_key]
        ctx.new_path()
        ctx.move_to(x + w, top_y)
        ctx.line_to(x + w + dx, top_y + dy)
        ctx.line_to(x + w + dx, y_base + dy)
        ctx.line_to(x + w, y_base)
        ctx.close_path()
        ctx.set_source_rgba(wr * 0.84, wg * 0.82, wb * 0.79, alpha)
        ctx.fill_preserve()
        ctx.set_source_rgba(er, eg, eb, alpha)
        ctx.set_line_width(1.8)
        ctx.stroke()

    # 3. Main front wall
    wr, wg, wb = COLORS[wall_key]
    ctx.new_path()
    ctx.rectangle(x, top_y, w, h)
    ctx.set_source_rgba(wr, wg, wb, alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.9)
    ctx.stroke()

    # 4. Pitched / Parapet Roof with 3D extrusion
    rr, rg, rb = COLORS[roof_key]
    roof_h = 24.0
    ctx.new_path()
    ctx.move_to(x - 6, top_y)
    ctx.line_to(x + w + 6, top_y)
    ctx.line_to(x + w - 8 + dx * 0.6, top_y - roof_h + dy * 0.6)
    ctx.line_to(x + 8 + dx * 0.6, top_y - roof_h + dy * 0.6)
    ctx.close_path()
    ctx.set_source_rgba(rr, rg, rb, alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.8)
    ctx.stroke()

    if depth_3d > 0.02:
        ctx.new_path()
        ctx.move_to(x + w + 6, top_y)
        ctx.line_to(x + w + dx + 4, top_y + dy)
        ctx.line_to(x + w - 8 + dx, top_y - roof_h + dy)
        ctx.line_to(x + w - 8 + dx * 0.6, top_y - roof_h + dy * 0.6)
        ctx.close_path()
        ctx.set_source_rgba(rr * 0.80, rg * 0.78, rb * 0.75, alpha)
        ctx.fill_preserve()
        ctx.set_source_rgba(er, eg, eb, alpha)
        ctx.set_line_width(1.6)
        ctx.stroke()

    # 5. Upper story windows catching warm light
    win_cols = max(2, int(w // 44))
    win_w = 22.0
    win_h = 26.0
    gap_x = (w - win_cols * win_w) / (win_cols + 1)
    wy = top_y + 22.0
    for c in range(win_cols):
        wx = x + gap_x + c * (win_w + gap_x)
        ctx.new_path()
        ctx.rectangle(wx, wy, win_w, win_h)
        glow = 0.5 + 0.5 * math.sin(warm_glow * 3.0 + c * 1.3)
        ctx.set_source_rgba(1.0, 0.92 + 0.05 * glow, 0.74 + 0.10 * glow, alpha)
        ctx.fill_preserve()
        ctx.set_source_rgba(er, eg, eb, alpha)
        ctx.set_line_width(1.5)
        ctx.stroke()
        ctx.new_path()
        ctx.move_to(wx, wy + win_h * 0.5)
        ctx.line_to(wx + win_w, wy + win_h * 0.5)
        ctx.stroke()

    # 6. Storefront Awning & Ground Floor Shop Window / Door
    ground_y = y_base - 56.0
    if has_awning:
        aw_h = 15.0
        ctx.new_path()
        ctx.move_to(x + 6, ground_y)
        ctx.line_to(x + w - 6, ground_y)
        ctx.line_to(x + w, ground_y + aw_h)
        ctx.line_to(x, ground_y + aw_h)
        ctx.close_path()
        ar, ag, ab = COLORS["terracotta"] if roof_key != "terracotta" else COLORS["sand"]
        ctx.set_source_rgba(ar, ag, ab, alpha)
        ctx.fill_preserve()
        ctx.set_source_rgba(er, eg, eb, alpha)
        ctx.set_line_width(1.5)
        ctx.stroke()

        n_stripes = max(3, int(w // 24))
        ctx.new_path()
        for s in range(1, n_stripes):
            sx = x + (w * s) / n_stripes
            ctx.move_to(sx, ground_y)
            ctx.line_to(sx, ground_y + aw_h)
        ctx.stroke()

    door_w = 24.0
    ctx.new_path()
    ctx.rectangle(x + 14, y_base - 38, door_w, 38)
    ctx.set_source_rgba(er, eg, eb, 0.88 * alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.stroke()

    disp_w = max(28.0, w - 58.0)
    ctx.new_path()
    ctx.rectangle(x + 44, y_base - 36, disp_w, 26)
    ctx.set_source_rgba(1.0, 0.95, 0.82, alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.5)
    ctx.stroke()

    if sign_label:
        ctx.save()
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(11.5)
        ext = ctx.text_extents(sign_label)
        sw = ext.width + 16
        sh = 19.0
        sx = x + (w - sw) * 0.5
        sy = top_y + 2.0
        ctx.new_path()
        ctx.rectangle(sx, sy, sw, sh)
        ctx.set_source_rgba(er, eg, eb, alpha)
        ctx.fill()
        cr, cg, cb = COLORS["cream"]
        ctx.set_source_rgba(cr, cg, cb, alpha)
        ctx.move_to(sx + 8, sy + 13.5)
        ctx.show_text(sign_label)
        ctx.restore()

    ctx.restore()


def draw_business_neighborhood(
    ctx: cairo.Context,
    t: float,
    cam_push: float = 0.0,
    extrude_3d: float = 0.0,
    pan_x: float = 0.0,
    horizon_y: float = 730.0,
    alpha: float = 1.0,
):
    """Draws the complete layered miniature business neighborhood."""
    if alpha <= 0.01:
        return
    ctx.save()

    draw_sky_and_clouds(ctx, t, pan_x=pan_x, horizon_y=horizon_y)

    scale = 1.0 + cam_push * 0.16
    ctx.translate(WIDTH * 0.5, horizon_y)
    ctx.scale(scale, scale)
    ctx.translate(-WIDTH * 0.5 - pan_x * 0.35, -horizon_y)

    er, eg, eb = COLORS["espresso"]

    # Distant rolling sage hills
    ctx.new_path()
    ctx.move_to(-200, horizon_y)
    for x in range(-200, WIDTH + 300, 80):
        hy = horizon_y - 52 - 24 * math.sin(x * 0.0045 + 0.8) - 12 * math.cos(x * 0.011)
        ctx.line_to(x, hy)
    ctx.line_to(WIDTH + 300, HEIGHT + 100)
    ctx.line_to(-200, HEIGHT + 100)
    ctx.close_path()
    sr, sg, sb = COLORS["sage_ground"]
    ctx.set_source_rgba(sr, sg, sb, 0.65 * alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, 0.45 * alpha)
    ctx.set_line_width(1.4)
    ctx.stroke()

    # Midground dusty green ground plane
    mid_y = horizon_y - 12
    ctx.new_path()
    ctx.move_to(-200, mid_y)
    for x in range(-200, WIDTH + 300, 90):
        hy = mid_y - 14 * math.cos(x * 0.0055 - 0.4)
        ctx.line_to(x, hy)
    ctx.line_to(WIDTH + 300, HEIGHT + 120)
    ctx.line_to(-200, HEIGHT + 120)
    ctx.close_path()
    dr, dg, db = COLORS["dusty_green"]
    ctx.set_source_rgba(dr, dg, db, 0.55 * alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, 0.55 * alpha)
    ctx.set_line_width(1.5)
    ctx.stroke()

    # Back-row low-rise office buildings
    back_buildings = [
        (150, mid_y + 6, 130, 125, "parchment", "sand", None, False),
        (390, mid_y + 6, 150, 148, "cream", "terracotta", None, False),
        (760, mid_y + 6, 165, 155, "parchment", "sand", None, False),
        (1140, mid_y + 6, 145, 140, "cream", "terracotta", None, False),
        (1490, mid_y + 6, 160, 150, "parchment", "sand", None, False),
    ]
    for bx, by, bw, bh, wk, rk, lbl, aw in back_buildings:
        draw_25d_storefront(
            ctx,
            bx + pan_x * 0.12,
            by,
            bw,
            bh,
            depth_3d=extrude_3d * 0.65,
            wall_key=wk,
            roof_key=rk,
            sign_label=lbl,
            has_awning=aw,
            warm_glow=t,
            alpha=0.88 * alpha,
        )

    # Foreground boulevard & warm sand sidewalk plane
    street_y = horizon_y + 58
    ctx.new_path()
    ctx.rectangle(-250, street_y - 48, WIDTH + 500, 260)
    ctx.set_source_rgba(COLORS["sage_ground"][0], COLORS["sage_ground"][1], COLORS["sage_ground"][2], alpha)
    ctx.fill()

    ctx.new_path()
    ctx.rectangle(-250, street_y - 16, WIDTH + 500, 34)
    ctx.set_source_rgba(COLORS["sand"][0], COLORS["sand"][1], COLORS["sand"][2], alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.8)
    ctx.stroke()

    ctx.new_path()
    ctx.rectangle(-250, street_y + 18, WIDTH + 500, 88)
    ctx.set_source_rgba(COLORS["parchment"][0] * 0.92, COLORS["parchment"][1] * 0.90, COLORS["parchment"][2] * 0.88, alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.6)
    ctx.stroke()

    ctx.save()
    ctx.set_dash([18.0, 14.0])
    ctx.set_source_rgba(COLORS["taupe"][0], COLORS["taupe"][1], COLORS["taupe"][2], 0.65 * alpha)
    ctx.set_line_width(2.0)
    ctx.new_path()
    ctx.move_to(-200, street_y + 62)
    ctx.line_to(WIDTH + 200, street_y + 62)
    ctx.stroke()
    ctx.restore()

    front_buildings = [
        (70, street_y - 14, 165, 132, "cream", "terracotta", "ATELIER CO.", True),
        (285, street_y - 14, 185, 156, "parchment", "sand", "KINETIC GOODS", True),
        (540, street_y - 14, 195, 144, "cream", "terracotta", "VERDANT LAB", True),
        (820, street_y - 14, 220, 168, "cream", "sand", "MERCHANT HQ", True),
        (1115, street_y - 14, 190, 148, "parchment", "terracotta", "SOLIS STUDIO", True),
        (1375, street_y - 14, 180, 160, "cream", "sand", "NORTHBOUND", True),
        (1615, street_y - 14, 175, 136, "parchment", "terracotta", "FORMA SUPPLY", True),
    ]
    for bx, by, bw, bh, wk, rk, lbl, aw in front_buildings:
        draw_25d_storefront(
            ctx,
            bx,
            by,
            bw,
            bh,
            depth_3d=extrude_3d,
            wall_key=wk,
            roof_key=rk,
            sign_label=lbl,
            has_awning=aw,
            warm_glow=t,
            alpha=alpha,
        )

    tree_positions = [42, 260, 508, 780, 1078, 1342, 1585, 1825]
    for idx, tx in enumerate(tree_positions):
        sc = 0.88 + 0.14 * (idx % 3)
        draw_stylized_tree(ctx, tx, street_y - 10, scale=sc, alpha=alpha)

    ctx.restore()


def draw_floating_signal_cue(
    ctx: cairo.Context,
    x: float,
    y: float,
    anchor_x: float,
    anchor_y: float,
    category: str,
    title: str,
    badge_key: str,
    progress: float = 1.0,
    kind: str = "card",
):
    """Draws a floating business signal cue rising from a storefront in Scene 1."""
    if progress <= 0.01:
        return
    ctx.save()
    cur_y = y + (1.0 - progress) * 28.0
    w, h = 268.0, 74.0

    cr, cg, cb = COLORS[badge_key]
    ctx.set_source_rgba(cr, cg, cb, 0.85 * progress)
    ctx.set_line_width(1.8)
    ctx.new_path()
    ctx.move_to(anchor_x, anchor_y)
    ctx.line_to(x + w * 0.5, cur_y + h)
    ctx.stroke()

    ctx.new_path()
    ctx.arc(anchor_x, anchor_y, 4.5, 0, math.pi * 2)
    ctx.fill()

    draw_card(ctx, x, cur_y, w, h, bg_key="cream", accent_key=badge_key, shadow_offset=5.0, alpha=progress)

    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(11.5)
    tr, tg, tb = COLORS["taupe"]
    ctx.set_source_rgba(tr, tg, tb, progress)
    ctx.move_to(x + 16, cur_y + 24)
    ctx.show_text(category.upper())

    ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(15.0)
    er, eg, eb = COLORS["espresso"]
    ctx.set_source_rgba(er, eg, eb, progress)
    ctx.move_to(x + 16, cur_y + 48)
    ctx.show_text(title)

    ix = x + w - 48
    iy = cur_y + 22
    ctx.set_source_rgba(cr, cg, cb, progress)
    ctx.set_line_width(2.0)
    if kind == "chart":
        pts = [(0, 26), (10, 18), (20, 21), (32, 6)]
        ctx.new_path()
        ctx.move_to(ix + pts[0][0], iy + pts[0][1])
        for px, py in pts[1:]:
            ctx.line_to(ix + px, iy + py)
        ctx.stroke()
    elif kind == "inventory":
        ctx.new_path()
        for b in range(3):
            bh = 10 + b * 7
            ctx.rectangle(ix + b * 11, iy + 28 - bh, 7, bh)
        ctx.fill()
    else:
        ctx.new_path()
        ctx.arc(ix + 16, iy + 15, 11, 0, math.pi * 2)
        ctx.stroke()
        ctx.new_path()
        ctx.arc(ix + 16, iy + 15, 4.5, 0, math.pi * 2)
        ctx.fill()

    ctx.restore()
