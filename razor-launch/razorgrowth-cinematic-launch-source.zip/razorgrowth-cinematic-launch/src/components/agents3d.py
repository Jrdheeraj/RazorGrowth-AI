"""
RazorGrowth AI — 3D Sculptural AI Employees & Workstation Companions
Represents AI employees as original 3D sculptural geometric desk companions:
- Marketing Agent (Terracotta #C65D42 accents)
- Product Agent (Muted Sage #5D8F6D accents)
- Designer Agent (Warm Ochre #D4943A accents)
- Plus subtle specialist nodes representing the 15-agent, 3-generation architecture.
"""
import math
import cairo
from src.styles.tokens import COLORS, FONT_MONO, FONT_SANS
from src.engine.camera3d import Scene3DRenderer
from src.components.ui_kit import draw_browser_window, draw_card, draw_pill_badge


def add_sculptural_agent_companion(
    renderer3d: Scene3DRenderer,
    center,
    role: str,
    t: float,
    scale: float = 1.0,
    alpha: float = 1.0,
):
    """Adds a 3D miniature workstation desk and sculptural geometric AI companion to the 3D scene."""
    if alpha <= 0.01:
        return
    cx, cy, cz = center
    bob = math.sin(t * 2.6 + cx * 0.01) * 5.5 * scale
    rot = t * 0.85

    if role == "marketing":
        accent = COLORS["terracotta"]
        accent_soft = COLORS["coral"]
    elif role == "product":
        accent = COLORS["sage"]
        accent_soft = COLORS["sage_light"]
    else:
        accent = COLORS["ochre"]
        accent_soft = COLORS["ochre_light"]

    renderer3d.add_box(
        center=(cx, cy - 38 * scale, cz),
        size=(136 * scale, 14 * scale, 96 * scale),
        base_rgb=COLORS["sand"],
        top_rgb=COLORS["cream"],
        stroke_rgb=COLORS["espresso"],
        stroke_width=1.6,
        alpha=alpha,
        rot_y=0.12 * math.sin(t * 0.4),
        contact_shadow=True,
    )

    renderer3d.add_cylinder(
        center=(cx, cy - 20 * scale, cz),
        radius=28 * scale,
        height=20 * scale,
        segments=10,
        base_rgb=COLORS["parchment"],
        top_rgb=COLORS["cream"],
        stroke_rgb=COLORS["espresso"],
        stroke_width=1.4,
        alpha=alpha,
    )

    if role == "marketing":
        renderer3d.add_box(
            center=(cx, cy + 4 * scale + bob * 0.5, cz),
            size=(34 * scale, 12 * scale, 34 * scale),
            base_rgb=accent,
            top_rgb=accent_soft,
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.5,
            alpha=alpha,
            rot_y=rot * 0.7,
            contact_shadow=False,
        )
        renderer3d.add_octahedron(
            center=(cx, cy + 36 * scale + bob, cz),
            radius=24 * scale,
            base_rgb=accent,
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.6,
            alpha=alpha,
            rot_y=-rot,
        )
        sat_ang = t * 1.8
        sx = cx + math.cos(sat_ang) * 42 * scale
        sz = cz + math.sin(sat_ang) * 42 * scale
        renderer3d.add_box(
            center=(sx, cy + 36 * scale + bob, sz),
            size=(11 * scale, 11 * scale, 11 * scale),
            base_rgb=COLORS["cream"],
            top_rgb=accent_soft,
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.3,
            alpha=alpha,
            rot_y=sat_ang,
            contact_shadow=False,
        )

    elif role == "product":
        renderer3d.add_box(
            center=(cx, cy + 10 * scale + bob * 0.6, cz),
            size=(32 * scale, 26 * scale, 32 * scale),
            base_rgb=accent,
            top_rgb=accent_soft,
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.6,
            alpha=alpha,
            rot_y=rot * 0.5,
            contact_shadow=False,
        )
        renderer3d.add_box(
            center=(cx, cy + 42 * scale + bob, cz),
            size=(22 * scale, 22 * scale, 22 * scale),
            base_rgb=COLORS["cream"],
            top_rgb=COLORS["cream_soft"],
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.6,
            alpha=alpha,
            rot_y=-rot * 0.8 + 0.6,
            contact_shadow=False,
        )
        renderer3d.add_cylinder(
            center=(cx, cy + 64 * scale + bob * 1.2, cz),
            radius=12 * scale,
            height=8 * scale,
            segments=8,
            base_rgb=accent,
            top_rgb=accent_soft,
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.4,
            alpha=alpha,
        )

    else:
        renderer3d.add_cylinder(
            center=(cx, cy + 12 * scale + bob * 0.5, cz),
            radius=22 * scale,
            height=26 * scale,
            segments=6,
            base_rgb=accent,
            top_rgb=accent_soft,
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.6,
            alpha=alpha,
        )
        renderer3d.add_octahedron(
            center=(cx, cy + 46 * scale + bob, cz),
            radius=20 * scale,
            base_rgb=COLORS["cream"],
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.6,
            alpha=alpha,
            rot_y=rot * 0.9,
        )
        renderer3d.add_box(
            center=(cx, cy + 46 * scale + bob, cz),
            size=(42 * scale, 6 * scale, 42 * scale),
            base_rgb=accent,
            top_rgb=accent_soft,
            stroke_rgb=COLORS["espresso"],
            stroke_width=1.4,
            alpha=alpha,
            rot_y=-rot * 0.6,
            contact_shadow=False,
        )


def draw_specialist_workstation_panel(
    ctx: cairo.Context,
    x: float,
    y: float,
    w: float,
    h: float,
    role_title: str,
    window_slug: str,
    accent_key: str,
    tasks: list,
    active_idx: int,
    progress: float = 1.0,
    t: float = 0.0,
):
    """Draws a specialist agent's floating browser-like workspace card with live analytical tasks."""
    if progress <= 0.01:
        return
    ctx.save()
    py = y + (1.0 - progress) * 32.0
    draw_browser_window(
        ctx,
        x,
        py,
        w,
        h,
        title=window_slug,
        alpha=progress,
        shadow_offset=8.0,
        header_h=34.0,
        tag_right="ACTIVE",
    )

    inner_x = x + 18
    inner_y = py + 50
    draw_pill_badge(
        ctx,
        inner_x,
        inner_y,
        role_title.upper(),
        bg_key="parchment",
        fg_key="espresso",
        dot_key=accent_key,
        alpha=progress,
        font_size=12.5,
    )

    er, eg, eb = COLORS["espresso"]
    ctx.set_source_rgba(er, eg, eb, 0.18 * progress)
    ctx.set_line_width(1.0)
    ctx.new_path()
    ctx.move_to(inner_x, inner_y + 38)
    ctx.line_to(x + w - 18, inner_y + 38)
    ctx.stroke()

    row_y = inner_y + 52
    row_h = 46.0
    for idx, (task_label, task_meta) in enumerate(tasks):
        is_active = idx == active_idx
        bg_k = "cream_soft" if is_active else "parchment"
        acc_k = accent_key if is_active else "taupe"
        draw_card(
            ctx,
            inner_x,
            row_y,
            w - 36,
            row_h,
            bg_key=bg_k,
            accent_key=acc_k,
            shadow_offset=3.0 if is_active else 0.0,
            alpha=progress,
        )

        ctx.select_font_face(FONT_SANS, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(14.5)
        ctx.set_source_rgba(er, eg, eb, progress)
        ctx.move_to(inner_x + 16, row_y + 20)
        ctx.show_text(task_label)

        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(11.5)
        tr, tg, tb = COLORS["taupe"]
        ctx.set_source_rgba(tr, tg, tb, progress)
        ctx.move_to(inner_x + 16, row_y + 37)
        ctx.show_text(task_meta)

        ar, ag, ab = COLORS[accent_key if is_active else "slate"]
        pulse = 1.0 + 0.25 * math.sin(t * 5.0 + idx) if is_active else 1.0
        ctx.new_path()
        ctx.arc(x + w - 36, row_y + row_h * 0.5, 4.5 * pulse, 0, math.pi * 2)
        ctx.set_source_rgba(ar, ag, ab, progress)
        ctx.fill()

        row_y += row_h + 10

    ctx.restore()


def draw_15_agent_ecosystem_bar(ctx: cairo.Context, x: float, y: float, w: float, h: float, t: float, alpha: float = 1.0):
    """Draws the documented 15-agent architecture across 3 architectural generations."""
    if alpha <= 0.01:
        return
    ctx.save()
    draw_card(ctx, x, y, w, h, bg_key="cream", accent_key="terracotta", shadow_offset=5.0, alpha=alpha)

    er, eg, eb = COLORS["espresso"]
    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(12.5)
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.move_to(x + 20, y + 24)
    ctx.show_text("COORDINATED ARCHITECTURE · 15 SPECIALIZED AI EMPLOYEES ACROSS 3 GENERATIONS")

    tr, tg, tb = COLORS["taupe"]
    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
    ctx.set_font_size(11.5)
    ctx.set_source_rgba(tr, tg, tb, alpha)
    ctx.move_to(x + 20, y + 44)
    ctx.show_text("GEN 1: SIGNAL & BI ANALYSTS   ·   GEN 2: MARKETING & PRODUCT STACKS   ·   GEN 3: DEBATE & WORKFLOW ORCHESTRATORS")

    node_start_x = x + w - 520
    node_y = y + h * 0.52
    spacing = 34.0

    ctx.set_source_rgba(er, eg, eb, 0.25 * alpha)
    ctx.set_line_width(1.4)
    ctx.new_path()
    ctx.move_to(node_start_x, node_y)
    ctx.line_to(node_start_x + 14 * spacing, node_y)
    ctx.stroke()

    node_palette = [
        "terracotta", "terracotta", "coral", "sage", "sage",
        "ochre", "terracotta", "sage", "ochre", "coral",
        "sage", "terracotta", "ochre", "sage", "terracotta",
    ]
    for i in range(15):
        nx = node_start_x + i * spacing
        ny = node_y + math.sin(t * 3.0 + i * 0.7) * 3.0
        col = COLORS[node_palette[i]]
        is_featured = i in (1, 7, 12)
        rad = 8.5 if is_featured else 5.5

        ctx.new_path()
        ctx.arc(nx, ny, rad, 0, math.pi * 2)
        ctx.set_source_rgba(col[0], col[1], col[2], alpha)
        ctx.fill_preserve()
        ctx.set_source_rgba(er, eg, eb, alpha)
        ctx.set_line_width(1.5)
        ctx.stroke()

    ctx.restore()
