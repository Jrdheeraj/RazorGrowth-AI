"""
RazorGrowth AI — Editorial Browser Window & UI Component Kit
Implements the strict RazorGrowth homepage visual specification:
- Dark espresso (#26150F) title bars with 3 small square window controls in upper-right
- Warm cream (#FFF3E1) interior surfaces with thin dark (#26150F) borders
- Subtle hard-edged sand-colored (#D9B993) offset shadows
- Terracotta (#C65D42) rectangular buttons with dark borders and modest shadows
- Clean clipping-mask animated headlines & monospaced metadata labels
"""
import math
import cairo
from src.styles.tokens import COLORS, FONT_DISPLAY, FONT_SANS, FONT_MONO


def rounded_rect_path(ctx: cairo.Context, x: float, y: float, w: float, h: float, r: float = 6.0):
    ctx.new_path()
    r = max(0.0, min(r, min(w, h) * 0.5))
    if r <= 0.5:
        ctx.rectangle(x, y, w, h)
        return
    ctx.arc(x + w - r, y + r, r, -math.pi * 0.5, 0)
    ctx.arc(x + w - r, y + h - r, r, 0, math.pi * 0.5)
    ctx.arc(x + r, y + h - r, r, math.pi * 0.5, math.pi)
    ctx.arc(x + r, y + r, r, math.pi, math.pi * 1.5)
    ctx.close_path()


def top_rounded_rect_path(ctx: cairo.Context, x: float, y: float, w: float, h: float, r: float = 6.0):
    ctx.new_path()
    r = max(0.0, min(r, min(w, h) * 0.5))
    ctx.arc(x + r, y + r, r, math.pi, math.pi * 1.5)
    ctx.arc(x + w - r, y + r, r, -math.pi * 0.5, 0)
    ctx.line_to(x + w, y + h)
    ctx.line_to(x, y + h)
    ctx.close_path()


def draw_browser_window(
    ctx: cairo.Context,
    x: float,
    y: float,
    w: float,
    h: float,
    title: str = "razorgrowth — welcome.app",
    alpha: float = 1.0,
    shadow_offset: float = 8.0,
    corner_r: float = 6.0,
    header_h: float = 38.0,
    bg_key: str = "cream",
    tag_right: str = None,
):
    """Draws the signature RazorGrowth browser-like window with espresso title bar & 3 square controls."""
    if alpha <= 0.01:
        return
    ctx.save()

    # 1. Hard-edged sand offset shadow + subtle dark rim
    if shadow_offset > 0:
        rounded_rect_path(ctx, x + shadow_offset, y + shadow_offset, w, h, corner_r)
        sr, sg, sb = COLORS["sand_dark"]
        ctx.set_source_rgba(sr, sg, sb, 0.78 * alpha)
        ctx.fill_preserve()
        er, eg, eb = COLORS["espresso"]
        ctx.set_source_rgba(er, eg, eb, 0.35 * alpha)
        ctx.set_line_width(1.2)
        ctx.stroke()

    # 2. Main warm cream body
    rounded_rect_path(ctx, x, y, w, h, corner_r)
    br, bg_c, bb = COLORS[bg_key]
    ctx.set_source_rgba(br, bg_c, bb, alpha)
    ctx.fill()

    # 3. Dark espresso title bar
    top_rounded_rect_path(ctx, x, y, w, header_h, corner_r)
    er, eg, eb = COLORS["espresso"]
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.fill()

    # 4. Outer dark espresso border around entire window
    rounded_rect_path(ctx, x, y, w, h, corner_r)
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(2.0)
    ctx.stroke()

    # 5. Title bar left brand dot + monospaced window title
    cr, cg, cb = COLORS["terracotta"]
    ctx.new_path()
    ctx.rectangle(x + 14, y + (header_h - 10) * 0.5, 10, 10)
    ctx.set_source_rgba(cr, cg, cb, alpha)
    ctx.fill()

    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(max(12.0, min(15.0, header_h * 0.39)))
    tr, tg, tb = COLORS["cream"]
    ctx.set_source_rgba(tr, tg, tb, 0.94 * alpha)
    ctx.move_to(x + 32, y + header_h * 0.66)
    ctx.show_text(title)

    # Optional subtle status tag before controls
    if tag_right:
        ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        ctx.set_font_size(12.0)
        ext = ctx.text_extents(tag_right)
        tx = x + w - 78 - ext.width
        sr, sg, sb = COLORS["sand"]
        ctx.set_source_rgba(sr, sg, sb, 0.85 * alpha)
        ctx.move_to(tx, y + header_h * 0.65)
        ctx.show_text(tag_right)

    # 6. Three small square window controls near the upper-right corner (strict brand geometry)
    sq_size = 10.0
    sq_y = y + (header_h - sq_size) * 0.5
    ctrl_colors = [COLORS["sand"], COLORS["coral"], COLORS["terracotta"]]
    for i in range(3):
        sq_x = x + w - 56 + i * 16
        ctx.new_path()
        ctx.rectangle(sq_x, sq_y, sq_size, sq_size)
        r_c, g_c, b_c = ctrl_colors[i]
        ctx.set_source_rgba(r_c, g_c, b_c, alpha)
        ctx.fill_preserve()
        ctx.set_source_rgba(er, eg, eb, 0.9 * alpha)
        ctx.set_line_width(1.0)
        ctx.stroke()

    ctx.restore()


def draw_card(
    ctx: cairo.Context,
    x: float,
    y: float,
    w: float,
    h: float,
    bg_key: str = "cream_soft",
    accent_key: str = None,
    shadow_offset: float = 5.0,
    alpha: float = 1.0,
    corner_r: float = 4.0,
):
    """Draws an editorial RazorGrowth card with thin dark border and sand offset shadow."""
    if alpha <= 0.01:
        return
    ctx.save()
    if shadow_offset > 0:
        rounded_rect_path(ctx, x + shadow_offset, y + shadow_offset, w, h, corner_r)
        sr, sg, sb = COLORS["sand"]
        ctx.set_source_rgba(sr, sg, sb, 0.85 * alpha)
        ctx.fill()

    rounded_rect_path(ctx, x, y, w, h, corner_r)
    br, bg_c, bb = COLORS[bg_key]
    ctx.set_source_rgba(br, bg_c, bb, alpha)
    ctx.fill_preserve()

    er, eg, eb = COLORS["espresso"]
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.6)
    ctx.stroke()

    if accent_key:
        ar, ag, ab = COLORS[accent_key]
        ctx.new_path()
        ctx.rectangle(x + 1, y + 1, 6, h - 2)
        ctx.set_source_rgba(ar, ag, ab, alpha)
        ctx.fill()
    ctx.restore()


def draw_button(
    ctx: cairo.Context,
    x: float,
    y: float,
    w: float,
    h: float,
    label: str,
    variant: str = "primary",  # "primary" (terracotta), "secondary" (cream), "approved" (sage)
    pressed: float = 0.0,
    alpha: float = 1.0,
    font_size: float = 17.0,
):
    """Draws a rectangular RazorGrowth button with dark border and modest physical shadow."""
    if alpha <= 0.01:
        return
    ctx.save()
    bx = x + pressed * 2.5
    by = y + pressed * 2.5

    # Hard offset shadow
    rounded_rect_path(ctx, x + 4.0, y + 4.0, w, h, 4.0)
    er, eg, eb = COLORS["espresso"]
    ctx.set_source_rgba(er, eg, eb, 0.85 * alpha)
    ctx.fill()

    if variant == "primary":
        fill_rgb = COLORS["terracotta"]
        txt_rgb = COLORS["cream"]
    elif variant == "approved":
        fill_rgb = COLORS["sage"]
        txt_rgb = COLORS["cream"]
    else:
        fill_rgb = COLORS["parchment"]
        txt_rgb = COLORS["espresso"]

    rounded_rect_path(ctx, bx, by, w, h, 4.0)
    ctx.set_source_rgba(fill_rgb[0], fill_rgb[1], fill_rgb[2], alpha)
    ctx.fill_preserve()
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.set_line_width(1.8)
    ctx.stroke()

    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(font_size)
    ext = ctx.text_extents(label)
    tx = bx + (w - ext.width) * 0.5 - ext.x_bearing
    ty = by + (h - ext.height) * 0.5 - ext.y_bearing
    ctx.set_source_rgba(txt_rgb[0], txt_rgb[1], txt_rgb[2], alpha)
    ctx.move_to(tx, ty)
    ctx.show_text(label)
    ctx.restore()


def draw_pill_badge(
    ctx: cairo.Context,
    x: float,
    y: float,
    text: str,
    bg_key: str = "parchment",
    fg_key: str = "espresso",
    dot_key: str = None,
    alpha: float = 1.0,
    font_size: float = 13.5,
):
    """Draws a crisp rectangular editorial badge (avoids excessive pill shapes per spec)."""
    if alpha <= 0.01:
        return 0.0
    ctx.save()
    ctx.select_font_face(FONT_MONO, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(font_size)
    ext = ctx.text_extents(text)
    pad_x = 12.0
    dot_space = 16.0 if dot_key else 0.0
    w = ext.width + pad_x * 2 + dot_space
    h = font_size + 13.0

    rounded_rect_path(ctx, x, y, w, h, 3.0)
    br, bg_c, bb = COLORS[bg_key]
    ctx.set_source_rgba(br, bg_c, bb, alpha)
    ctx.fill_preserve()

    er, eg, eb = COLORS["espresso"]
    ctx.set_source_rgba(er, eg, eb, 0.85 * alpha)
    ctx.set_line_width(1.3)
    ctx.stroke()

    if dot_key:
        dr, dg, db = COLORS[dot_key]
        ctx.new_path()
        ctx.arc(x + pad_x + 4, y + h * 0.5, 4.2, 0, math.pi * 2)
        ctx.set_source_rgba(dr, dg, db, alpha)
        ctx.fill()

    fr, fg, fb = COLORS[fg_key]
    ctx.set_source_rgba(fr, fg, fb, alpha)
    ctx.move_to(x + pad_x + dot_space, y + h * 0.5 + font_size * 0.35)
    ctx.show_text(text)
    ctx.restore()
    return w


def draw_masked_headline(
    ctx: cairo.Context,
    x: float,
    y: float,
    text: str,
    size: float = 72.0,
    color_key: str = "espresso",
    progress: float = 1.0,
    align: str = "left",
    font_family: str = FONT_DISPLAY,
    weight=cairo.FONT_WEIGHT_BOLD,
):
    """Reveals a headline line using a clean vertical clipping mask & positional rise."""
    if progress <= 0.01:
        return 0.0
    ctx.save()
    ctx.select_font_face(font_family, cairo.FONT_SLANT_NORMAL, weight)
    ctx.set_font_size(size)
    ext = ctx.text_extents(text)

    draw_x = x
    if align == "center":
        draw_x = x - ext.width * 0.5
    elif align == "right":
        draw_x = x - ext.width

    clip_top = y - size * 1.08
    clip_h = size * 1.38
    ctx.new_path()
    ctx.rectangle(draw_x - 20, clip_top, ext.width + 40, clip_h)
    ctx.clip()

    y_offset = (1.0 - progress) * (size * 0.85)
    r, g, b = COLORS[color_key]
    ctx.set_source_rgba(r, g, b, min(1.0, progress * 1.35))
    ctx.move_to(draw_x, y + y_offset)
    ctx.show_text(text)
    ctx.restore()
    return ext.width


def draw_split_accent_headline(
    ctx: cairo.Context,
    x: float,
    y: float,
    prefix_text: str,
    accent_text: str,
    size: float = 88.0,
    p1: float = 1.0,
    p2: float = 1.0,
    align: str = "left",
    accent_key: str = "terracotta",
):
    """Draws a headline where the second segment is emphasized in terracotta on the same line."""
    ctx.save()
    ctx.select_font_face(FONT_DISPLAY, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(size)
    ext1 = ctx.text_extents(prefix_text + " ")
    ext2 = ctx.text_extents(accent_text)
    total_w = ext1.width + ext2.width

    start_x = x
    if align == "center":
        start_x = x - total_w * 0.5
    ctx.restore()

    draw_masked_headline(ctx, start_x, y, prefix_text, size=size, color_key="espresso", progress=p1, align="left")
    draw_masked_headline(
        ctx,
        start_x + ext1.width,
        y,
        accent_text,
        size=size,
        color_key=accent_key,
        progress=p2,
        align="left",
    )


def draw_line_chart(
    ctx: cairo.Context,
    x: float,
    y: float,
    w: float,
    h: float,
    points_norm,
    progress: float = 1.0,
    stroke_key: str = "terracotta",
    fill_area: bool = True,
    alpha: float = 1.0,
):
    """Draws a self-drawing data chart with subtle editorial grid lines."""
    if alpha <= 0.01 or progress <= 0.01:
        return
    ctx.save()
    er, eg, eb = COLORS["taupe"]
    ctx.set_source_rgba(er, eg, eb, 0.22 * alpha)
    ctx.set_line_width(1.0)
    ctx.new_path()
    for i in range(4):
        gy = y + (h * i) / 3.0
        ctx.move_to(x, gy)
        ctx.line_to(x + w, gy)
    ctx.stroke()

    reveal_w = w * progress
    ctx.new_path()
    ctx.rectangle(x - 4, y - 10, reveal_w + 8, h + 20)
    ctx.clip()

    coords = []
    n = len(points_norm)
    for i, val in enumerate(points_norm):
        px = x + (w * i) / max(1, n - 1)
        py = y + h * (1.0 - val)
        coords.append((px, py))

    sr, sg, sb = COLORS[stroke_key]
    if fill_area and len(coords) >= 2:
        ctx.new_path()
        ctx.move_to(coords[0][0], y + h)
        for px, py in coords:
            ctx.line_to(px, py)
        ctx.line_to(coords[-1][0], y + h)
        ctx.close_path()
        ctx.set_source_rgba(sr, sg, sb, 0.16 * alpha)
        ctx.fill()

    ctx.new_path()
    ctx.move_to(coords[0][0], coords[0][1])
    for px, py in coords[1:]:
        ctx.line_to(px, py)
    ctx.set_source_rgba(sr, sg, sb, alpha)
    ctx.set_line_width(2.8)
    ctx.stroke()

    for px, py in coords:
        if px <= x + reveal_w:
            ctx.new_path()
            ctx.arc(px, py, 4.0, 0, math.pi * 2)
            cr, cg, cb = COLORS["cream"]
            ctx.set_source_rgba(cr, cg, cb, alpha)
            ctx.fill_preserve()
            ctx.set_source_rgba(sr, sg, sb, alpha)
            ctx.set_line_width(2.0)
            ctx.stroke()

    ctx.restore()


def draw_human_cursor(ctx: cairo.Context, x: float, y: float, click_pulse: float = 0.0, alpha: float = 1.0):
    """Draws a crisp editorial pointer cursor with optional click ring."""
    if alpha <= 0.01:
        return
    ctx.save()
    if click_pulse > 0.01:
        rad = 10.0 + click_pulse * 28.0
        cr, cg, cb = COLORS["terracotta"]
        ctx.new_path()
        ctx.arc(x, y, rad, 0, math.pi * 2)
        ctx.set_source_rgba(cr, cg, cb, (1.0 - click_pulse) * 0.75 * alpha)
        ctx.set_line_width(2.5)
        ctx.stroke()

    scale = 1.0 - 0.12 * math.sin(min(1.0, click_pulse * 2.0) * math.pi) if click_pulse > 0 else 1.0
    ctx.translate(x, y)
    ctx.scale(scale, scale)

    pts = [
        (0, 0),
        (0, 26),
        (7, 20),
        (12, 31),
        (16, 29),
        (11, 18),
        (20, 18),
    ]
    ctx.new_path()
    ctx.move_to(pts[0][0] + 3, pts[0][1] + 4)
    for px, py in pts[1:]:
        ctx.line_to(px + 3, py + 4)
    ctx.close_path()
    ctx.set_source_rgba(0.15, 0.08, 0.06, 0.28 * alpha)
    ctx.fill()

    ctx.new_path()
    ctx.move_to(pts[0][0], pts[0][1])
    for px, py in pts[1:]:
        ctx.line_to(px, py)
    ctx.close_path()
    er, eg, eb = COLORS["espresso"]
    ctx.set_source_rgba(er, eg, eb, alpha)
    ctx.fill_preserve()
    cr, cg, cb = COLORS["cream"]
    ctx.set_source_rgba(cr, cg, cb, alpha)
    ctx.set_line_width(2.0)
    ctx.stroke()
    ctx.restore()
