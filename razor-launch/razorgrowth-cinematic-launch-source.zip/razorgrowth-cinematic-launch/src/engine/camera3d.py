"""
RazorGrowth AI — 3D Perspective Camera, Lighting & Sculptural Geometry Engine
"""
import math
import cairo
from src.styles.tokens import COLORS, WIDTH, HEIGHT


class Camera3D:
    def __init__(
        self,
        pos=(0.0, 180.0, -680.0),
        target=(0.0, 40.0, 0.0),
        fov=950.0,
        cx=WIDTH * 0.5,
        cy=HEIGHT * 0.54,
    ):
        self.pos = list(pos)
        self.target = list(target)
        self.fov = fov
        self.cx = cx
        self.cy = cy
        self._update_basis()

    def _update_basis(self):
        fx = self.target[0] - self.pos[0]
        fy = self.target[1] - self.pos[1]
        fz = self.target[2] - self.pos[2]
        flen = math.sqrt(fx * fx + fy * fy + fz * fz) or 1.0
        self.fwd = (fx / flen, fy / flen, fz / flen)

        # World up is (0, 1, 0)
        up_w = (0.0, 1.0, 0.0)
        rx = up_w[1] * self.fwd[2] - up_w[2] * self.fwd[1]
        ry = up_w[2] * self.fwd[0] - up_w[0] * self.fwd[2]
        rz = up_w[0] * self.fwd[1] - up_w[1] * self.fwd[0]
        rlen = math.sqrt(rx * rx + ry * ry + rz * rz) or 1.0
        self.right = (rx / rlen, ry / rlen, rz / rlen)

        ux = self.fwd[1] * self.right[2] - self.fwd[2] * self.right[1]
        uy = self.fwd[2] * self.right[0] - self.fwd[0] * self.right[2]
        uz = self.fwd[0] * self.right[1] - self.fwd[1] * self.right[0]
        self.up = (ux, uy, uz)

    def project(self, pt):
        dx = pt[0] - self.pos[0]
        dy = pt[1] - self.pos[1]
        dz = pt[2] - self.pos[2]

        vx = dx * self.right[0] + dy * self.right[1] + dz * self.right[2]
        vy = dx * self.up[0] + dy * self.up[1] + dz * self.up[2]
        vz = dx * self.fwd[0] + dy * self.fwd[1] + dz * self.fwd[2]

        if vz < 40.0:
            vz = 40.0
        scale = self.fov / vz
        sx = self.cx + vx * scale
        sy = self.cy - vy * scale
        return (sx, sy, vz, scale)


class Scene3DRenderer:
    """Painter's algorithm 3D mesh renderer with matte ceramic/editorial lighting."""

    def __init__(self, ctx: cairo.Context, cam: Camera3D):
        self.ctx = ctx
        self.cam = cam
        self.faces = []
        # Warm editorial key light from upper-left-front
        lx, ly, lz = -0.45, 0.72, -0.52
        llen = math.sqrt(lx * lx + ly * ly + lz * lz)
        self.light_dir = (lx / llen, ly / llen, lz / llen)

    def _shade_color(self, base_rgb, normal, shade_strength=0.22):
        nx, ny, nz = normal
        nlen = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
        nx, ny, nz = nx / nlen, ny / nlen, nz / nlen
        dot = nx * self.light_dir[0] + ny * self.light_dir[1] + nz * self.light_dir[2]
        # Matte editorial lighting: controlled warm contrast without specular glare
        factor = 1.0 + dot * shade_strength
        return (
            max(0.0, min(1.0, base_rgb[0] * factor)),
            max(0.0, min(1.0, base_rgb[1] * factor)),
            max(0.0, min(1.0, base_rgb[2] * factor)),
        )

    def add_face(self, pts3d, base_rgb, stroke_rgb=None, stroke_width=1.4, alpha=1.0, shade=0.20, bias=0.0):
        proj_pts = [self.cam.project(p) for p in pts3d]
        avg_z = sum(p[2] for p in proj_pts) / len(proj_pts) + bias

        # Compute face normal
        if len(pts3d) >= 3:
            ax, ay, az = (
                pts3d[1][0] - pts3d[0][0],
                pts3d[1][1] - pts3d[0][1],
                pts3d[1][2] - pts3d[0][2],
            )
            bx, by, bz = (
                pts3d[2][0] - pts3d[0][0],
                pts3d[2][1] - pts3d[0][1],
                pts3d[2][2] - pts3d[0][2],
            )
            nx = ay * bz - az * by
            ny = az * bx - ax * bz
            nz = ax * by - ay * bx
        else:
            nx, ny, nz = (0.0, 1.0, 0.0)

        shaded = self._shade_color(base_rgb, (nx, ny, nz), shade)
        self.faces.append({
            "type": "poly",
            "z": avg_z,
            "pts2d": [(p[0], p[1]) for p in proj_pts],
            "fill": shaded,
            "stroke": stroke_rgb if stroke_rgb is not None else COLORS["espresso"],
            "lw": stroke_width,
            "alpha": alpha,
        })

    def add_box(
        self,
        center,
        size,
        base_rgb,
        top_rgb=None,
        stroke_rgb=None,
        stroke_width=1.5,
        alpha=1.0,
        rot_y=0.0,
        contact_shadow=True,
    ):
        cx, cy, cz = center
        w, h, d = size[0] * 0.5, size[1] * 0.5, size[2] * 0.5
        cos_y, sin_y = math.cos(rot_y), math.sin(rot_y)

        def tr(lx, ly, lz):
            rx = lx * cos_y - lz * sin_y
            rz = lx * sin_y + lz * cos_y
            return (cx + rx, cy + ly, cz + rz)

        if contact_shadow and alpha > 0.15:
            pad = 12.0
            sh_y = cy - h + 0.5
            s_pts = [
                tr(-w - pad, sh_y - cy, -d - pad * 0.6),
                tr(w + pad, sh_y - cy, -d - pad * 0.6),
                tr(w + pad, sh_y - cy, d + pad * 0.6),
                tr(-w - pad, sh_y - cy, d + pad * 0.6),
            ]
            self.add_face(
                s_pts,
                COLORS["espresso"],
                stroke_rgb=None,
                stroke_width=0.0,
                alpha=0.12 * alpha,
                shade=0.0,
                bias=25.0,
            )

        v = [
            tr(-w, -h, -d), tr(w, -h, -d), tr(w, h, -d), tr(-w, h, -d),
            tr(-w, -h, d),  tr(w, -h, d),  tr(w, h, d),  tr(-w, h, d),
        ]
        # 6 faces with outward vertex winding
        face_defs = [
            ([v[0], v[1], v[2], v[3]], base_rgb),                      # Front
            ([v[5], v[4], v[7], v[6]], base_rgb),                      # Back
            ([v[4], v[0], v[3], v[7]], base_rgb),                      # Left
            ([v[1], v[5], v[6], v[2]], base_rgb),                      # Right
            ([v[3], v[2], v[6], v[7]], top_rgb or base_rgb),           # Top
            ([v[4], v[5], v[1], v[0]], base_rgb),                      # Bottom
        ]
        for f_pts, col in face_defs:
            self.add_face(
                f_pts,
                col,
                stroke_rgb=stroke_rgb,
                stroke_width=stroke_width,
                alpha=alpha,
            )

    def add_pitched_roof(self, center, size, roof_rgb, stroke_rgb=None, stroke_width=1.5, alpha=1.0, rot_y=0.0):
        cx, cy, cz = center
        w, h, d = size[0] * 0.5, size[1], size[2] * 0.5
        cos_y, sin_y = math.cos(rot_y), math.sin(rot_y)

        def tr(lx, ly, lz):
            rx = lx * cos_y - lz * sin_y
            rz = lx * sin_y + lz * cos_y
            return (cx + rx, cy + ly, cz + rz)

        b0, b1, b2, b3 = tr(-w, 0, -d), tr(w, 0, -d), tr(w, 0, d), tr(-w, 0, d)
        r0, r1 = tr(-w * 0.85, h, 0), tr(w * 0.85, h, 0)

        self.add_face([b0, b1, r1, r0], roof_rgb, stroke_rgb, stroke_width, alpha)
        self.add_face([b2, b3, r0, r1], roof_rgb, stroke_rgb, stroke_width, alpha)
        self.add_face([b3, b0, r0], roof_rgb, stroke_rgb, stroke_width, alpha)
        self.add_face([b1, b2, r1], roof_rgb, stroke_rgb, stroke_width, alpha)

    def add_cylinder(self, center, radius, height, segments, base_rgb, top_rgb=None, stroke_rgb=None, stroke_width=1.2, alpha=1.0):
        cx, cy, cz = center
        h2 = height * 0.5
        top_ring = []
        bot_ring = []
        for i in range(segments):
            ang = (2.0 * math.pi * i) / segments
            x = cx + math.cos(ang) * radius
            z = cz + math.sin(ang) * radius
            top_ring.append((x, cy + h2, z))
            bot_ring.append((x, cy - h2, z))

        for i in range(segments):
            ni = (i + 1) % segments
            quad = [bot_ring[i], bot_ring[ni], top_ring[ni], top_ring[i]]
            self.add_face(quad, base_rgb, stroke_rgb, stroke_width * 0.6, alpha)

        self.add_face(top_ring, top_rgb or base_rgb, stroke_rgb, stroke_width, alpha, bias=-2.0)

    def add_octahedron(self, center, radius, base_rgb, stroke_rgb=None, stroke_width=1.4, alpha=1.0, rot_y=0.0):
        cx, cy, cz = center
        r = radius
        top = (cx, cy + r * 1.25, cz)
        bot = (cx, cy - r * 1.25, cz)
        ring = []
        for i in range(4):
            ang = rot_y + i * (math.pi * 0.5)
            ring.append((cx + math.cos(ang) * r, cy, cz + math.sin(ang) * r))
        for i in range(4):
            ni = (i + 1) % 4
            self.add_face([ring[i], ring[ni], top], base_rgb, stroke_rgb, stroke_width, alpha)
            self.add_face([ring[ni], ring[i], bot], base_rgb, stroke_rgb, stroke_width, alpha)

    def add_line3d(self, p0, p1, rgb, width=2.2, alpha=1.0, dashed=False, progress=1.0):
        if progress <= 0.0:
            return
        ep = (
            p0[0] + (p1[0] - p0[0]) * progress,
            p0[1] + (p1[1] - p0[1]) * progress,
            p0[2] + (p1[2] - p0[2]) * progress,
        )
        proj0 = self.cam.project(p0)
        proj1 = self.cam.project(ep)
        avg_z = (proj0[2] + proj1[2]) * 0.5 - 5.0
        self.faces.append({
            "type": "line",
            "z": avg_z,
            "p0": (proj0[0], proj0[1]),
            "p1": (proj1[0], proj1[1]),
            "rgb": rgb,
            "lw": width,
            "alpha": alpha,
            "dashed": dashed,
        })

    def render(self):
        # Painter's algorithm: sort back-to-front (largest z first)
        self.faces.sort(key=lambda f: f["z"], reverse=True)
        ctx = self.ctx
        for item in self.faces:
            if item["type"] == "poly":
                pts = item["pts2d"]
                if not pts:
                    continue
                ctx.new_path()
                ctx.move_to(pts[0][0], pts[0][1])
                for px, py in pts[1:]:
                    ctx.line_to(px, py)
                ctx.close_path()
                r, g, b = item["fill"]
                ctx.set_source_rgba(r, g, b, item["alpha"])
                if item["lw"] > 0 and item["stroke"] is not None:
                    ctx.fill_preserve()
                    sr, sg, sb = item["stroke"]
                    ctx.set_source_rgba(sr, sg, sb, item["alpha"])
                    ctx.set_line_width(item["lw"])
                    ctx.stroke()
                else:
                    ctx.fill()
            elif item["type"] == "line":
                ctx.save()
                r, g, b = item["rgb"]
                ctx.set_source_rgba(r, g, b, item["alpha"])
                ctx.set_line_width(item["lw"])
                if item["dashed"]:
                    ctx.set_dash([7.0, 5.0])
                ctx.move_to(item["p0"][0], item["p0"][1])
                ctx.line_to(item["p1"][0], item["p1"][1])
                ctx.stroke()
                ctx.restore()
